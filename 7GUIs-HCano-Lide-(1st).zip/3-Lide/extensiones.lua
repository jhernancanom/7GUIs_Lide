function printf ( str, ... )
    io.stdout:write( (tostring(str)..'\n'):format(...))
end---

function lide.generror( msg, show)
	if show then error(msg) end
	return false
end

-- verifica si es booleano o no, so generror es true entnces genera el error automaticamente al no ser boleano
function lide.isbool ( value, generror )
	if (value == true) or (value == false) then
		return true  -- is a boolean
	else
		if generror then
			error("The value must be boolean.")
		else
			return false -- is not a boolean
		end
	end
end

function lide.isstring( value, generror )
	if type(value) == 'string' then
		return true
	else
		return lide.generror("The value must be string.", true) -- si not a boolean
	end
end

function lide.round (num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

lide.osname = lide.platform.getOSName()