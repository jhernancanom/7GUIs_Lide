-- Contador.lua

--  
-- Contador en lide 
--  

require 'modules.classes'  	-- import classes

App = app

app.frmCounter = require 'forms.frmCounter'

app.frmCounter:show()

--