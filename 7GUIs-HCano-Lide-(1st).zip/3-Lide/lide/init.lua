-- ///////////////////////////////////////////////////////////////////////////////
-- // Name:        init.lua
-- // Purpose:     Define/initialize framework values
-- // Created:     2016/01/03
-- // Copyright:   (c) 2016 Dario Cano
-- // License:     lide license
-- ///////////////////////////////////////////////////////////////////////////////

wx = require 'wx'

lide = {
	cons   = {}, 	--> This table saves all constants
	errorf = {}, 	--> This table stores all error functions
	
	core   = {
		error = {},	--> stores all variables related to exceptions control
		base  = {},
		lua   = { type = type },
		file  = {},  --> stores all variables related to file handling
	},

	classes = {
		widgets  = {},
		controls = {},
	}, 	--> stores all classes

	platform = {}, --> platform related values
}

app = { }

function app.getWorkDir( ... )
	if lide.platform.getOSName() == 'Unix' then
		return io.popen 'echo $PWD' : read '*l'
	elseif lide.platform.getOSName() == 'Windows' then
		return io.popen 'CD' : read '*l'
	else
		lide.core.error.lperr 'this function is not implemented on this platform.'
	end
end

require 'lide.core.thlua' --> import

lide.core.error = require 'lide.core.error' --> exceptions control
lide.core.oop   = require 'lide.core.oop.init'
lide.core.base  = require 'lide.core.base'
lide.core.file  = require 'lide.core.file'	--> File Handling


------------------------------------------
-- base values:
class = lide.core.oop.class
enum  = lide.core.base.enum

----------------------------------------------------------------------
--- Alignment constants:
--	used by BoxSizer,

enum -- wxAlignment 
{
    ALIGN_NOT    = wx.wxALIGN_NOT, 
    ALIGN_LEFT   = wx.wxALIGN_LEFT, 
    ALIGN_TOP    = wx.wxALIGN_TOP, 
    ALIGN_RIGHT  = wx.wxALIGN_RIGHT, 
    ALIGN_BOTTOM = wx.wxALIGN_BOTTOM, 
    ALIGN_CENTER = wx.wxALIGN_CENTER, 
    ALIGN_CENTRE = wx.wxALIGN_CENTRE, 
    ALIGN_MASK   = wx.wxALIGN_MASK,
    
    ALIGN_CENTER_HORIZONTAL = wx.wxALIGN_CENTER_HORIZONTAL, 
    ALIGN_CENTRE_HORIZONTAL = wx.wxALIGN_CENTRE_HORIZONTAL, 
    ALIGN_CENTER_VERTICAL   = wx.wxALIGN_CENTER_VERTICAL, 
    ALIGN_CENTRE_VERTICAL   = wx.wxALIGN_CENTRE_VERTICAL, 
}

enum { -- wxMessageDialog
	 ICON_ASTERISK    = wx.wxICON_ASTERISK ,
	 ICON_ERROR  	  = wx.wxICON_ERROR,
	 ICON_EXCLAMATION = wx.wxICON_EXCLAMATION,
	 ICON_HAND  	  = wx.wxICON_HAND,
	 ICON_INFORMATION = wx.wxICON_INFORMATION,
	 ICON_MASK  	  = wx.wxICON_MASK,
	 ICON_QUESTION    = wx.wxICON_QUESTION,
	 ICON_STOP  	  = wx.wxICON_STOP,
	 ICON_WARNING     = wx.wxICON_WARNING,
}
----------------------------------------------------------------------

lide.core.base.maxid = 1000
------------------------------------------

function lide.platform.getArchName( ... )
	return wx.wxPlatformInfo:Get():GetArchName()          --> 32 bit
end

function lide.platform.getOSVersion( ... )
	return wx.wxPlatformInfo:Get():getOSVersion()  --> 32 bitend
end

function lide.platform.getOSName( ... )
	return wx.wxPlatformInfo:Get():GetOperatingSystemFamilyName()
end

-------------------------------------

lide.classes    = require 'lide.classes.init'


return lide