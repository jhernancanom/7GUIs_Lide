Lide SDK - Crossplatform App Framework

Visit http://lide.thedary.com/en/documentation for more info.