-- Temperatura.lua

--  
-- Temperatura en lide 
--  

require 'modules.classes'  	-- import classes
require 'extensiones'		-- extensiones al lenguaje lua

-- App = app

app.frmTemperatura = require 'forms.frmTemperatura'

app.frmTemperatura:show()

--