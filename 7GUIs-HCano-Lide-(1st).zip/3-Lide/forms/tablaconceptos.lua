--- lnomina/forms/tablaconceptos.lua
--- Ventana principal
--- 2016/03/29

app.AddResource(app.MODULES.TBL_CONCEPTOS, function ( resID )
      app.formTablaConceptos:show(true)  
end)

local Label    = lide.classes.controls.label
local Textbox  = lide.classes.controls.textbox
local Combobox = lide.classes.controls.combobox

local VAEForm = require "forms.vaeform"

local isNumber = lide.core.base.isnumber

local thisWIN = VAEForm:new { Name = 'formTablaConceptos',
    Title = 'Tabla de conceptos',
    DBTable = SQLT.CONCEPTOS,
    
    ViewerCols = 'CODIGO, DESCRIPCIO, DEV_DED, ADMORA, PORCENTAJE, OBSERVACIO',

    Width = 470, Height = 150,
    
    SaveButton   = { PosX = 373, PosY = 80 },
    CancelButton = { PosX = 259, PosY = 80 },
}

thisWIN.Lobj:setMinSize( thisWIN.Lobj:getWidth(), thisWIN.Lobj:getHeight() )
thisWIN.Lobj:setMaxSize( thisWIN.Lobj:getWidth(), thisWIN.Lobj:getHeight() )

thisWIN.onShow:setHandler( function ( this )

   thisWIN:setViewMode(false)
   this:getSender():LoadRecord( this:getSender().DBTable:getFirstRecord() )

end, thisWIN)

thisWIN.onSaving:setHandler( function ( this )
   return true
end, thisWIN)

----------------------------------------------------------------------------------------------------
---> thisWIN.lblCodigo thisWIN.txtCodigo

thisWIN.lblCodigo  =  Label:new { Name =  ( thisWIN:getName() .. '.lblCodigo' ),
  Parent = thisWIN.Panel, 
  PosX = 10 , PosY = 20, Width = 65, Height = 20,
  Text = "Codigo:",
  -- Font = "Courier New"
}

thisWIN.txtCodigo  = Textbox { Name =  ( thisWIN:getName() .. '.txtCodigo' ),
  Parent = thisWIN.Panel, 
  PosX = 80 , PosY = 17, Width = 130, Height = 23, 
  --  Font = "Courier New" 
}

thisWIN.txtCodigo.sqlField = 'CODIGO'

---< thisWIN.lblCodigo thisWIN.txtCodigo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblClase thisWIN.txtActivo

thisWIN.lblClase  =  Label:new  {  Name =  ( thisWIN:getName() .. '.lblClase' ),
  Parent = thisWIN.Panel, 
  PosX = 250, PosY = 20, Width = 75, Height = 20,
  Text = "Clase:",
  -- Font = "Courier New"
}

thisWIN.cmbClase  = Combobox { Name =  ( thisWIN:getName() .. '.cmbClase' ),
  Parent = thisWIN.Panel,
  PosX = 330, PosY = 17, Width = 130, Height = 23, 
  -- Font = "Courier New", 
  Flags = CB_READONLY , Text = ''
}

thisWIN.cmbClase.sqlField = 'DEV_DED'
thisWIN.cmbClase.sqlFieldChoices = { "NETO", "+", "-" } 

---< thisWIN.lblClase thisWIN.txtActivo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblConcepto thisWIN.txtConcepto

thisWIN.lblConcepto = Label:new{ Name =  ( thisWIN:getName() .. '.lblConcepto' ),
  Parent = thisWIN.Panel,
  PosX = 10 , PosY = 50, Width = 65, Height = 20,
  Text = "Concepto:",
  -- Font = "Courier New"
}

thisWIN.txtConcepto  = Textbox { Name =  ( thisWIN:getName() .. '.txtConcepto' ),
  Parent = thisWIN.Panel,
  PosX = 80 , PosY = 47, Width = 380, Height = 23,
  -- Font = "Courier New"
}

thisWIN.txtConcepto.sqlField = 'DESCRIPCIO'

---< thisWIN.lblConcepto thisWIN.txtConcepto
----------------------------------------------------------------------------------------------------

return thisWIN