-- lnomina/forms/formloginuser.lua
-- Ventana de login para la aplicacion. 
--  

local Form    = lide.classes.widgets.form
local Label   = lide.classes.controls.label
local Textbox = lide.classes.controls.textbox
local messagebox = lide.core.base.messagebox
local Date    = require 'modules.thdate'

local thisWIN = Form:new { 
   Name = 'formLoginUser',
   Flags  = WIN_DEFAULT_STYLE + WIN_TOOL_WINDOW + WIN_STAY_ON_TOP,
   Title  = 'Acceder a la aplicaci?'
}

if lide.platform.getOSName()  == 'Windows' then
   thisWIN:setWidth(300) thisWIN:setHeight(145)
elseif lide.platform.getOSName() == 'Unix' then
   thisWIN:setWidth(290) thisWIN:setHeight(115)
end

thisWIN:setMaxSize( thisWIN:getWidth(), thisWIN:getHeight() )
thisWIN:setMinSize( thisWIN:getWidth(), thisWIN:getHeight() )

thisWIN.onClose:setHandler( function ( this )
   os.exit()
end)

thisWIN.onShow:setHandler( 
    function ( thisEVT, SHOWING )

        if SHOWING then
          thisWIN.DateTextbox:setText ( tostring( Date:new( DATE_TODAY ) ) )
          
          thisWIN.UserTextbox:setSelection(0, -1)

            -- 1. Si hay un periodo abierto, se trabaja sobre ese
            -- 2. Si no hay un periodo abierto se trabaja sobre el ultimo cerrado
            -- 3. Si no existe un periodo, entonces se trabaja sobre la fecha de hoy
            
            app.PeriodoProceso = rawget( SQLT.PERIODOS:list('*', ('where ABIERTO == "S"')), 1) 

            if app.PeriodoProceso then
                -- Hay un periodo abierto.

            else
                -- No hay un periodo abierto (CARGAR EL ULTIMO)
                app.PeriodoProceso = rawget( SQLT.PERIODOS:list('*', ('ORDER BY RECORDID DESC LIMIT 1')), 1)
                
                if not app.PeriodoProceso then
                    -- No existen periodos (CARGAR LA FECHA DE HOY)
                    app.PeriodoProceso = tostring(Date:new ( DATE_TODAY ))
                end
            end

            if app.PeriodoProceso == 'string' then
                thisWIN.DateTextbox:setText( app.PeriodoProceso )
                --- Eliminar el valor para poder trabajarlo:
                app.PeriodoProceso = nil
            else
                thisWIN.DateTextbox:setText( app.PeriodoProceso.FEC_TERMIN )
            end

            -- Eliminamos la variable ya que el periododeRpoceso
            --app.PeriodoProceso = nil

        end
    end
)

thisWIN.userLabel= Label:new { 
   Name = 'formLoginUser.UserLabel', Parent = thisWIN,
   PosX = 11, PosY = 13, Width = 77, Height = 20,  
   Text   = "Usuario:"
}

thisWIN.UserTextbox = Textbox:new { 
   Name = 'formLoginUser.UserTextbox', Parent = thisWIN,
   PosX = 111, PosY = 9, Width = 170, Height = 23,  
   Text = 'Admin'
}

thisWIN.PassLabel = Label:new {
   Name = 'formLoginUser.PassLabel', Parent = thisWIN,
   PosX   = 11, PosY = 37, Width  = 77, Height = 20,
   Text   = 'Contrase?:'
}

thisWIN.PassTextbox = Textbox:new {
   Name = 'formLoginUser.PassTextbox', Parent = thisWIN,
   PosX   = 111, PosY = 33, Width = 170, Height = 23,
   Flags = TC_PASSWORD + TC_PROCESS_ENTER, -- PassWord Input, Procces Enter
   
   Text   = "admin"
}

thisWIN.InfoLabel = Label:new {
   Name = 'formLoginUser.InfoLabel', Parent  = thisWIN,
   PosX = 9, PosY = 63, ---Width = 170, Height = 20,  
   Text = "Contraseña incorrecta!",
}

thisWIN.InfoLabel:setFont("Courier New", 10)
thisWIN.InfoLabel:setVisible(false)

thisWIN.DateLabel= Label:new {
   Name = 'formLoginUser.DateLabel', Parent  = thisWIN,
   PosX = 11, PosY = 60, Width = 170, Height = 20,  
   Text = "Fecha proceso:",
}

thisWIN.DateTextbox = Textbox:new {
   Name = 'formLoginUser.DateTextbox', Parent  = thisWIN,
   PosX = 9, PosY = 80, Width = 85, Height = 22,
   Text = tostring(Date:new (DATE_TODAY)),
}

thisWIN.PassTextbox.onKeyDown:setHandler ( function ( this, nKeyCode )
    local ENTER, INTRO = 13, 370
    
    if (nKeyCode == ENTER) or (nKeyCode == INTRO) then --> 13 = ENTER
      thisWIN.LoginButton.onClick:call( ) -- Ejecutar el evento OnClick
    end
end)

thisWIN.DateTextbox.onKeyDown:setHandler ( thisWIN.PassTextbox.onKeyDown:getHandler() )

thisWIN.LoginButton = Button:new {
   Name = 'formLoginUser.LoginButton', Parent = thisWIN,
   PosX = 195, PosY = 75,-- Width = 92, Height = 24,
   Text = 'Entrar',
}

thisWIN.LoginButton.onClick:setHandler ( function ( ... ) 
    App.loggedUser = thisWIN.UserTextbox:getText()
      
    if App.USERS[App.loggedUser] then
        App.loggedUser = App.USERS[App.loggedUser]
    else
        messagebox("El usuario no existe", "", ICON_ERROR)
        return false
    end    
    
    APP_PASSWORD = App.loggedUser:GetPassword()
    USR_PASSWORD = thisWIN.PassTextbox:getText()
    
    if APP_PASSWORD == USR_PASSWORD then
        thisWIN.InfoLabel:setText("Correcto, iniciando...")
        thisWIN.InfoLabel:setVisible(true) 
       
        thisWIN.LoginButton:setEnabled(false)

        thisWIN:setVisible(false)
        app.windMain:setStatusText("Usuario: " .. App.loggedUser:GetUserName())
        app.windMain:setEnabled(true)
        app.windMain:show()
        
        --printf( '%s', tostring(app.PeriodoProceso) )

        local FechaPeriodo = Date:new( tostring(thisWIN.DateTextbox:getText() ))
        local nQuincena
        
        if tonumber(FechaPeriodo:getDay()) <= 15 then
            nQuincena = 1
        elseif tonumber(FechaPeriodo:getDay()) >= 16 then
            nQuincena = 2
        end

        local sPeriodo = ('%s-%s-%s'):format( FechaPeriodo:getYear(), FechaPeriodo:getMonth 'string', nQuincena)

        app.PeriodoProceso = rawget (
            SQLT.PERIODOS:list('*',('where PERIODO == "%s"') -- ADD LIMIT 1
                :format( sPeriodo )), 1)
          
          printf('where PERIODO == "%s"', ('%s-%s-%s'):format( FechaPeriodo:getYear(), FechaPeriodo:getMonth 'string', nQuincena )
          )
        --[[or rawget ( 
            SQLT.PERIODOS:list('*', ('ORDER BY RECORDID DESC LIMIT 1')
        ), 1)]]

        --- Si el periodo no existe, dar la posibilidad de crearlo        
        if not app.PeriodoProceso then
            lide.core.base.messagebox 'La fecha de Proceso especificada corresponde a un periodo inexistente.\nPor favor rellene los datos del periodos y haga click en guardar.'
            app.formMaePeriodos:show(true)
--            app.formMaePeriodos.Toolbar.onToolClick:call( ID_NEW_RECORD )
  --          app.formMaePeriodos.txtPeriodo:setText( sPeriodo )

        elseif app.PeriodoProceso.ABIERTO == 'N' then
            lide.core.base.messagebox 'La fecha de proceso especificada corresponde a un periodo cerrado.\nSolo podr?ver/consultar registros.'
            app.windMain.Menubar[3]:setEnabled(app.MODULES.LIQUIDARFORM      , false)
            app.windMain.Menubar[3]:setEnabled(app.MODULES.PRC_PERIODO_CERRAR, false)
        end

    else
        local Timer = lide.classes.timer
        local defWDTH = thisWIN.LoginButton:getWidth()
        local defTXT  = thisWIN.LoginButton:getText()

        local timWrongPass = Timer:new( lide.core.base.newid (),         
        function () 
             thisWIN.LoginButton:setEnabled(true)
             thisWIN.DateTextbox:setEnabled(true)
             thisWIN.PassTextbox:setEnabled(true)
             thisWIN.LoginButton:setText ( defTXT  )
             thisWIN.LoginButton:setWidth( defWDTH )
             thisWIN.LoginButton:setPosX ( 195 )
             thisWIN.PassTextbox:setSelection(0, -1)
        end)
        
        timWrongPass:start( 2000, true)
        thisWIN.LoginButton:setEnabled(false)
        thisWIN.DateTextbox:setEnabled(false)
        thisWIN.PassTextbox:setEnabled(false)
        thisWIN.LoginButton:setText( 'Contrase? incorrecta!' )
        thisWIN.LoginButton:setWidth( 150 )
        thisWIN.LoginButton:setPosX ( 130 )
    end
end)

thisWIN.txtPassword = thisWIN.PassTextbox

return thisWIN