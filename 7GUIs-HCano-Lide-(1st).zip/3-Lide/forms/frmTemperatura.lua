-- frmTemperatura.lua

--  
-- Contador en lide 
--  

local Form    = lide.classes.widgets.form
local Textbox = lide.classes.controls.textbox
local Label   = lide.classes.controls.label
 isBoolean = lide.core.base.isboolean

local thisWIN = Form:new { 
   Name = 'frmTemperatura',
   Flags  = WIN_DEFAULT_STYLE + WIN_TOOL_WINDOW + WIN_STAY_ON_TOP,
   Title  = 'Acceder a la aplicaci�n'
}

thisWIN.btnContar = Button:new {
   Name = 'frmTemperatura.btnContar', Parent = thisWIN,
   PosX = 150, PosY = 70,-- Width = 92, Height = 24,
   Text = 'Calcular',
}

if lide.platform.getOSName()  == 'Windows' then
   thisWIN:setWidth(300) thisWIN:setHeight(145)
elseif lide.platform.getOSName() == 'Unix' then
   thisWIN:setWidth(290) thisWIN:setHeight(115)
end

thisWIN:setMaxSize( thisWIN:getWidth(), thisWIN:getHeight() )
thisWIN:setMinSize( thisWIN:getWidth(), thisWIN:getHeight() )

thisWIN.onClose:setHandler( function ( this )
   os.exit()
end)

thisWIN.txtCelsius = Textbox:new { 
   Name = 'frmTemperatura.txtCelsius', Parent = thisWIN,
   PosX = 10, PosY = 20, Width = 50, Height = 25,  
   Text = '0'
}
thisWIN.txtCelsius:setEditable(true)


thisWIN.lblCelsius= Label:new { 
   Name = 'frmTemperatura.lblCelsius', Parent = thisWIN,
   PosX = 70, PosY = 20, Width = 60, Height = 20,  
   Text   = "Celsius ="
}

thisWIN.txtFarenheit = Textbox:new { 
   Name = 'frmTemperatura.txtFarenheit', Parent = thisWIN,
   PosX =130, PosY = 20, Width = 50, Height = 25,  
   Text = '0'
}
thisWIN.txtFarenheit:setEditable(true)

thisWIN.lblFarenheit= Label:new { 
   Name = 'frmTemperatura.lblFarenheit', Parent = thisWIN,
   PosX =190, PosY = 20, Width = 60, Height = 20,  
   Text   = "Farenheit"
}


thisWIN.btnContar.onClick:setHandler ( function ( ... ) 
   -- aqu� se escribe lo que el prog debe hcer
   -- al dar click en el bot�n
   local nC = 0
   local nF = 0
   nC = tonumber(thisWIN.txtCelsius  :getText())
   nF = tonumber(thisWIN.txtFarenheit:getText())
   
   if nC and nC>0 then
      nF = nC * (9/5) + 32	  
      thisWIN.txtFarenheit:setText(tostring(nF))
   
   elseif nF and nF>0 then
      nC = (nF - 32) * (5/9)	  
      thisWIN.txtCelsius  :setText(tostring(nC))
   
   end
   
end)

return thisWIN

--