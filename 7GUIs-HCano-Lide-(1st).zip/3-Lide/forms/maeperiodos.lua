local BUFFER   = {}
local Label    = lide.classes.controls.label
local Textbox  = lide.classes.controls.textbox
local Combobox = lide.classes.controls.combobox
local Date     = app.modules.thdate

local VAEForm = require "forms.vaeform" -- import View and Edit Form class
local DATE_TODAY = DATE_TODAY


---
--- Registramos una funcion local para verificar si el usuario escribio el periodo correctamente
---
local function match_periodo( str )
    if  (tonumber(str:sub(1,1))) and (tonumber(str:sub(2,2)))
    and (tonumber(str:sub(3,3))) and (tonumber(str:sub(4,4)))
    and ((str:sub(5,5) == '-') ) and (tonumber(str:sub(6,6)))
    and (tonumber(str:sub(7,7))) and ((str:sub(8,8) == '-') )
    and (tonumber(str:sub(9,9)) < 3) and ( tonumber(str:sub(9,9)) > 0 ) then
        if tonumber(str:sub(6,7)) <= 12 then
            return true
        else
            return false
        end    
        return true
    else
        return false
    end
end

local thisWIN = VAEForm:new {  Name  = 'maeperiodos',
    Title = 'Maestro de periodos', Width = 540, Height = 200,
    
    -- Indicamos la tabla sobre la que va a trabajar el formulario
    DBTable = SQLT.PERIODOS,

    -- Indicamos que columnas se muestran en el visor (separadas por comas):
    --
    ViewerCols = 'PERIODO, DESCRIPCIO, FEC_INICIA, FEC_TERMIN, ABIERTO, VR_TRASPOR, S_MINIMO',

    SaveButton   = { PosX = 445, PosY = 135 },
    CancelButton = { PosX = 330, PosY = 135 },
}

thisWIN.Lobj:setMinSize( thisWIN.Lobj:getWidth(), thisWIN.Lobj:getHeight() )
thisWIN.Lobj:setMaxSize( thisWIN.Lobj:getWidth(), thisWIN.Lobj:getHeight() )

-- Agregamos manejadores a los eventos del formulario:
--
local messagebox = lide.core.base.messagebox
local function onshow_handler ( this, SHOWING )
    if SHOWING then
        if app.PeriodoProceso then
            thisWIN:LoadRecord ( 
                thisWIN.DBTable:getLastRecord()
            )
        else
            --lide.core.base.messagebox 'No hay periodos abiertos'
            this:getSender():LoadRecord ( 
                thisWIN.DBTable:getLastRecord()
            )
        end
    end
    thisWIN.Toolbar.onToolClick:call (ID_RELOAD_RECORD)
end

thisWIN.onShow:setHandler( onshow_handler, thisWIN )

thisWIN.Lobj.onClose:setHandler( function ( ... )
    
    -- Al cerrar la ventana maestro de periodos verificamos si creamos algun periodo.
    app.PeriodoAbierto = rawget( SQLT.PERIODOS:list('*', 'where ABIERTO == "S"'), 1) 
    
    -- Si creamos algun periodo, habilitamos la opcion de liquidar
    if app.PeriodoAbierto then
        app.windMain.Menubar[3]:setEnabled(App.MODULES.LIQUIDARFORM, true)
    end

    thisWIN.Lobj:setVisible(false)
end )

thisWIN.onNewRegistry:setHandler( function ( this )
    local sPeriodo, nQuincena  = '%s-%s-%s' -- yyyy-mm-dd
    
    local dtToday = Date:new ( DATE_TODAY )
    
    if tonumber(dtToday.Day) <= 15 then
        nQuincena = 1
    elseif tonumber(dtToday.Day) >= 16 then
        nQuincena = 2
    end
    
    local sPeriodo = sPeriodo:format(dtToday.Year, dtToday.Month, nQuincena)
    printf('%s', 'onNewRegistry')
    this:getSender().txtPeriodo:setSelection( 0, -1 )
    this:getSender().cmbPeriodoAbierto:setSelection(0)
    this:getSender().txtPeriodo:setText( sPeriodo )    
end, thisWIN)


thisWIN.onEditRegistry:setHandler( function ( bEditing )
    printf('%s', 'onEditRegistry')
    thisWIN.txtPeriodo:setEnabled(false);
    thisWIN.txtDescripcion:setSelection( # thisWIN.txtDescripcion:getText(), -1);
end, thisWIN)

local function onSavingEvent ( this, tDatos, CurrentRecord )
    printf('%s', 'onSavingEvent:')
    --- Nos fijamos en que el periodo que se quiere agregar no exista ya en la base de datos
    ---
    --- printf('%s', CurrentRecord)
    if rawget( SQLT.PERIODOS:list('*', ('where PERIODO == "%s"' ):format(tDatos.PERIODO)), 1)
    and CurrentRecord == NEW_RECORD then
        lide.core.base.messagebox ('Este periodo ya existe en la base de datos.\nNo es posible agregarlo otra vez.', 'Error', OK + ICON_EXCLAMATION )
        return false
    end
    
    if not match_periodo(tDatos.PERIODO) then
        lide.core.base.messagebox ('El campo "Periodo" no contiene un periodo v�lido.\n\nPor favor ingrese un texto v�lido o continue el proceso con el que hab�a por defecto.', 'Error', OK + ICON_EXCLAMATION )
        thisWIN.txtPeriodo:setSelection( #tDatos.PERIODO -1, #tDatos.PERIODO )
        return false
    end

    for _, value in pairs(tDatos) do
        if (value == '') then
           lide.core.base.messagebox ('Parece que hay campos vac�os.\n\nRellene todos los campos y luego presione "Guardar".', 'Error', OK + ICON_EXCLAMATION )
           return false
        end
    end
        
    -- Antes de guardar comprobamos que se quieren cerrar PERIODOS manualmente
    if tDatos.ABIERTO == 'N' then
        if lide.core.base.messagebox ('Seguro que quiere cerrar este periodo manualmente?\n\nEsto podria traer problemas futuros...', 'Advertencia', YES_NO + NO_DEFAULT + ICON_EXCLAMATION ) == YES then
            return true
        else
            return false
        end
    end

    table.foreach( tDatos, messagebox )

    return true
end

thisWIN.onSaving:setHandler( onSavingEvent )

----------------------------------------------------------------------------------------------------
---> thisWIN.lblPeriodo thisWIN.txtPeriodo

    thisWIN.lblPeriodo  =  Label:new { Name =  ( thisWIN:getName().. '.lblPeriodo' ),
      Parent = thisWIN.Panel,
      PosX   = 10 , PosY = 20, Width = 65, Height = 20,
      Text   = 'Periodo:',--- Font = "Courier New",
    }

    thisWIN.txtPeriodo  = Textbox:new { Name =  ( thisWIN:getName().. '.txtPeriodo' ),
      Parent = thisWIN.Panel,
      PosX = 120 , PosY = 17, Width = 130, Height = 23, Text = 'muscuo',
      Flags = TC_PROCESS_ENTER,
    }

    thisWIN.txtPeriodo:setEnabled(false)
    thisWIN.txtPeriodo.sqlField = 'PERIODO'
    
    thisWIN.txtPeriodo.onKeyDown:setHandler ( function ( this, nKeyCode )
        local ENTER, INTRO = 13, 370

        if (nKeyCode == ENTER) or (nKeyCode == INTRO) then
            local nDiaTermino, nDiaInicio, nQuincena
            local oFechaInicial, oFechaTermino
            local sDescripcion, sDateSTR, sPeriodo

            sPeriodo     = thisWIN.txtPeriodo:getText()
            sDescripcion = 'Quincena %d de %s'
            nQuincena    = tonumber(sPeriodo:sub( #sPeriodo, # sPeriodo ))
            
            io.stdout : write ('sPeriodo '..sPeriodo)

            -- Si lo que hay escrito no es un string de Periodo valido: no ejecutar lo demas
            if not match_periodo (sPeriodo) then
                return false
            end

            --- Si el ultimo caracter es "2", entonces
            --- Convertimos la ultima parte de la fecha (el dia) en '16' para que corresponda a la segunda quincena
            if ( nQuincena == 2 ) then
                --- Creamos un objeto fecha temporal para trabajar con el
                sDateSTR   = ( sPeriodo:sub(1, # sPeriodo -1) .. '16' )
                nDiaInicio  = 16
                --> nDiaTermino = LastMonthDay ::: Este valor lo seteamos luego cuando hayamos creado el objeto Date.

            --- Si el ultimo caracter es "1", entonces utilizamos el string de sPeriodo como constructor:
            elseif ( nQuincena == 1 ) then
                sDateSTR    = sPeriodo
                nDiaInicio  = 1
                nDiaTermino = 15
            end

            --- Creamos un objeto fecha temporal para trabajar con el
            local dtTemp = Date:new( sDateSTR )

            nDiaTermino  = nDiaTermino or dtTemp:getLastMonthDay()
            
            sDescripcion = sDescripcion:format( nQuincena, dtTemp:getMonth 'name' )

            oFechaInicial = Date:new ( tostring( dtTemp ) )
            oFechaInicial:setDay(nDiaInicio)

            oFechaTermino = Date:new ( tostring( dtTemp ) )
            oFechaTermino:setDay(nDiaTermino)

            thisWIN.txtFechaInicial:setText ( tostring(oFechaInicial) )
            thisWIN.txtFechaTermino:setText ( tostring(oFechaTermino) )
            thisWIN.txtDescripcion:setText  ( tostring(sDescripcion ) )
            
            -- Si existe un periodo anterior gestionamos
            if ( thisWIN.DBTable:getLastRecord() ) then
                thisWIN.txtValorTransporte:setText( thisWIN.DBTable:getLastRecord().VR_TRASPOR ) -- LLenamos los datos del periodo anterior
                thisWIN.txtSalarioMin:setText     ( thisWIN.DBTable:getLastRecord().S_MINIMO   ) -- LLenamos los datos del periodo anterior
            end        
        end
    end)

---< thisWIN.lblPeriodo thisWIN.txtPeriodo
----------------------------------------------------------------------------------------------------    

----------------------------------------------------------------------------------------------------
---> thisWIN.lblPeriodoAbierto thisWIN.txtPeriodoAbierto

    thisWIN.lblPeriodoAbierto = Label:new { Name =  ( thisWIN:getName().. '.lblPeriodoAbierto' ),
        Parent = thisWIN.Panel,
        PosX = 300, PosY = 20, Width = 100, Height = 20, 
        
        Text = "Periodo abierto:", 
        --Font = "Courier New"
    }

    thisWIN.cmbPeriodoAbierto = Combobox:new { Name =  ( thisWIN:getName().. '.cmbPeriodoAbierto' ),
        Parent = thisWIN.Panel,
        PosX = 400, PosY = 17,
        Width = 130, Height = 23,
        Flags  = CB_READONLY,
        ReadOnly = true,
    }

    thisWIN.cmbPeriodoAbierto:setEnabled(false)
    thisWIN.cmbPeriodoAbierto.sqlField        = 'ABIERTO'
    thisWIN.cmbPeriodoAbierto.sqlFieldChoices = { 'S', 'N' }

---< thisWIN.lblPeriodoAbierto thisWIN.txtPeriodoAbierto
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblFechaInicial thisWIN.txtFechaInicial

    thisWIN.lblFechaInicial = Label:new { Name =  ( thisWIN:getName().. '.lblFechaInicial' ),
        Parent = thisWIN.Panel,
        PosX = 10 , PosY = 50, Width = 100, Height = 20,
        Text = "Fecha inicial:", 
--        Flags = wx.wxALIGN_RIGHT
        --Font = "Courier New"
    }

    thisWIN.txtFechaInicial = Textbox:new { Name =  ( thisWIN:getName().. '.txtFechaInicial' ),
        Parent = thisWIN.Panel,
        PosX = 120 , PosY = 47, Width = 130, Height = 23,
        --Font = "Courier New"
    }

    thisWIN.txtFechaInicial:setEnabled(false)
    thisWIN.txtFechaInicial.sqlField = 'FEC_INICIA'

---< thisWIN.lblFechaInicial thisWIN.txtFechaInicial
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblFechaTermino thisWIN.txtFechaTermino

    thisWIN.lblFechaTermino = Label:new { Name =  ( thisWIN:getName().. '.lblFechaTermino' ),
        Parent = thisWIN.Panel, 
        PosX = 300, PosY = 50, Width = 100, Height = 20,
        Text = "Fecha termino :", 
        --Font = "Courier New" 
    }

    thisWIN.txtFechaTermino = Textbox:new { Name =  ( thisWIN:getName().. '.txtFechaTermino' ),
        Parent = thisWIN.Panel, 
        PosX = 400, PosY = 47, Width = 130, Height = 23, 
        --Font = "Courier New"
    }

    thisWIN.txtFechaTermino:setEnabled(false)
    thisWIN.txtFechaTermino.sqlField = 'FEC_TERMIN'

---< thisWIN.lblFechaTermino thisWIN.txtFechaTermino
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblValorTransporte thisWIN.txtValorTransporte

    thisWIN.lblValorTransporte = Label:new { Name =  ( thisWIN:getName().. '.lblValorTransporte' ),
        Parent = thisWIN.Panel,
        PosX = 10 , PosY = 80, Width = 100, Height = 20,
        Text = "Valor transporte:", 
        --Font = "Courier New"
    }

    thisWIN.txtValorTransporte = Textbox:new { Name =  ( thisWIN:getName().. '.txtValorTransporte' ),
        Parent = thisWIN.Panel,
        PosX = 120 , PosY = 77, Width = 130, Height = 23,
    --    Font = "Courier New"
    }

    thisWIN.txtValorTransporte:setEnabled(false)
    thisWIN.txtValorTransporte.sqlField = 'VR_TRASPOR'

---< thisWIN.lblValorTransporte thisWIN.txtValorTransporte
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblSalarioMin thisWIN.txtSalarioMin

    thisWIN.lblSalarioMin = Label:new { Name =  ( thisWIN:getName().. '.lblSalarioMin' ),
        Parent = thisWIN.Panel, 
        PosX = 300, PosY = 80, Width = 100, Height = 23,
        Text = "Salario Minimo :", 
        --Font = "Courier New" 
    }

    thisWIN.txtSalarioMin = Textbox:new { Name =  ( thisWIN:getName().. '.txtSalarioMin' ),
        Parent = thisWIN.Panel, 
        PosX = 400, PosY = 77, Width = 100, Height = 23, 
        --Font = "Courier New"
    }

    thisWIN.txtSalarioMin:setEnabled(false)
    thisWIN.txtSalarioMin.sqlField = 'S_MINIMO'

---< thisWIN.lblSalarioMin thisWIN.txtSalarioMin
----------------------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------------------
---> thisWIN.lblDescripcion thisWIN.txtDescripcion

    thisWIN.lblDescripcion = Label { Name =  ( thisWIN:getName().. '.lblDescripcion' ),
      Parent = thisWIN.Panel, 
      PosX = 10 , PosY = 110, Width = 100, Height = 20,

      --PosX = 300, PosY = 20, 
       -- Width = 65, Height = 20,
      Text = "Descripcion:", 
      -- Font = "Courier New"
    }

    thisWIN.txtDescripcion = Textbox { Name =  ( thisWIN:getName().. '.txtDescripcion' ),
      Parent = thisWIN.Panel, 
       Width = 130 + 280, Height = 23 , 
       PosX   = 120 , PosY = 107,
--      Font = "Courier New", -- 
       --Flags = TC_NOVSCROLL + TC_MULTILINE ,
    }
    
    thisWIN.txtDescripcion:setEnabled(false)
    thisWIN.txtDescripcion.sqlField = 'DESCRIPCIO'

---< thisWIN.lblDescripcion thisWIN.txtDescripcion
----------------------------------------------------------------------------------------------------

App.AddResource(App.MODULES.MAE_PERIODOS, function ( resID )
    thisWIN:show()
end)

return thisWIN