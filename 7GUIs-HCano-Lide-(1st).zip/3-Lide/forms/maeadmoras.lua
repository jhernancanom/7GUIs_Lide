-- TablaAdmoras.lua
-- tomado de maeadmoras.lua
-- HCano Nov-2016

app.AddResource(App.MODULES.MAE_ADMORAS, function ( resID )
    app.formMaeAdmoras:show()  
end)


local Label    = lide.classes.controls.label
local Textbox  = lide.classes.controls.textbox
local Combobox = lide.classes.controls.combobox


local VAEForm = require "forms.vaeform"

local thisWIN = VAEForm:new { 
    Name = 'formMaeAdmoras',
    Title = 'Tabla de Admoras',
    DBTable = SQLT.ADMORAS,
    
    ViewerCols = 'CODIGO, ACTIVA, NIT, DESCRIPCIO, NOMBRE, EMAIL',

    Width = 480, Height = 150,

    SaveButton   = { PosX = 373, PosY = 80 },
    CancelButton = { PosX = 259, PosY = 80 },
}

thisWIN.Lobj:setMinSize( thisWIN.Lobj:getWidth(), thisWIN.Lobj:getHeight() )
thisWIN.Lobj:setMaxSize( thisWIN.Lobj:getWidth(), thisWIN.Lobj:getHeight() )

thisWIN.onShow:setHandler( function ( this )

   thisWIN:setViewMode(false)
   this:getSender():LoadRecord( this:getSender().DBTable:getFirstRecord() )

end, thisWIN)

thisWIN.onSaving:setHandler( function ( this )
   return true
end, thisWIN)

----------------------------------------------------------------------------------------------------
---> thisWIN.lblCodigo thisWIN.txtCodigo

    thisWIN.lblCodigo  =  Label:new {
      Parent = thisWIN.Panel, Name = ( thisWIN:getName() .. '.lblCodigo' ),
      PosX = 10 , PosY = 20, Width = 65, Height = 20,
      --Width = 65, 
      --Height = 20,
      Text = "Codigo  :", 
      -- Font = "Courier New"
    }

    thisWIN.txtCodigo  = Textbox:new {
      Parent = thisWIN.Panel, Name = ( thisWIN:getName() .. '.txtCodigo' ),
      PosX = 100 , PosY = 17, Width = 100, Height = 23, 
      -- Font = "Courier New" 
    }

    -- thisWIN.txtCodigo:setEnabled(false)
    thisWIN.txtCodigo.sqlField = 'CODIGO'


---< thisWIN.lblCodigo thisWIN.txtCodigo
----------------------------------------------------------------------------------------------------    

----------------------------------------------------------------------------------------------------
---> thisWIN.lblNombre thisWIN.txtNombre

    thisWIN.lblNombre = Label:new { Name = 'formMaeAdmoras.lblNombre',
        Parent = thisWIN.Panel,
        PosX = 10 , PosY = 50,-- Width = 65, Height = 20,
        Text = "Nombre corto:",
        -- Font = "Courier New"
    }

    thisWIN.txtNombre  = Textbox:new { Name = 'formMaeAdmoras.txtNombre',
        Parent = thisWIN.Panel,
        PosX = 100 , PosY = 47, Width = 100, Height = 23,
        -- Font = "Courier New"
    }


    thisWIN.txtNombre:setEnabled(false)
    thisWIN.txtNombre.sqlField = 'DESCRIPCIO'

---< thisWIN.lblNombre thisWIN.txtNombre
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblNIT thisWIN.txtActivo

    thisWIN.lblNIT  =  Label  { Name = 'formMaeAdmoras.lblNIT',
      Parent = thisWIN.Panel, 
      PosX = 300-70, PosY = 20, --Width = 75, Height = 20,
      Text = "NIT    :",
      -- Font = "Courier New"
    }

    thisWIN.txtNIT  = Textbox { Name = 'formMaeAdmoras.txtNIT',
      Parent = thisWIN.Panel, 
      PosX = 400-80, PosY = 17, Width = 150, Height = 23, 
      --Font = "Courier New", -- Flags = CB_READONLY ,
    }
    
    thisWIN.txtNIT:setEnabled(false)
    thisWIN.txtNIT.sqlField = 'NIT'

---< thisWIN.lblNIT thisWIN.txtActivo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblNombreLargo thisWIN.txtNombreLargo

    thisWIN.lblNombreLargo = Label:new { Name = 'formMaeAdmoras.lblNombreLargo',
        Parent = thisWIN.Panel, 
        PosX = 300-70, PosY = 50,-- Width = 75, Height = 20,
        Text = "Nombre largo :",
        -- Font = "Courier New" 
    }

    thisWIN.txtNombreLargo = Textbox:new { Name = 'formMaeAdmoras.txtNombreLargo',
        Parent = thisWIN.Panel, 
        PosX = 400-80, PosY = 47, Width = 150, Height = 23, 
        -- Font = "Courier New"
    }

    thisWIN.txtNombreLargo:setEnabled(false)
    thisWIN.txtNombreLargo.sqlField = 'NOMBRE'

---< thisWIN.lblNombreLargo thisWIN.txtNombreLargo
----------------------------------------------------------------------------------------------------

return thisWIN