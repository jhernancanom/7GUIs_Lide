--- lnomina/forms/windmain.lua
--- Ventana principal
--- 2016/03/29

local BUFFER    = {}
local Label     = lide.classes.controls.label
local Textbox   = lide.classes.controls.textbox
local Combobox  = lide.classes.controls.combobox

local GridTable = lide.classes.gridtable

local VAEForm = require "forms.vaeform"

local newID = lide.core.base.newid

local thisWIN = VAEForm:new { Name = "maempl_window",
    Title = "Maestro de empleados",

    DBTable = SQLT.NOMMAE,
    
    -- Los campos que se van a ver en el Viewer asociado
    --
    ViewerCols = 'CODIGO, ACTIVO, DOCUMENTO, NOMBRE, APELLIDOS, CARGO, AFP, EPS, SALARIO, EMAIL',
    
    Width  = 590, Height = 270,

    CancelButton = { PosX = 379, PosY = 200 },
    SaveButton   = { PosX = 493, PosY = 200 },
}

thisWIN.Lobj:setMinSize( thisWIN.Lobj:getWidth(), thisWIN.Lobj:getHeight() )
thisWIN.Lobj:setMaxSize( thisWIN.Lobj:getWidth(), thisWIN.Lobj:getHeight() )

thisWIN.onEditRegistry:setHandler( function ( this, sCode )
   this:getSender().txtCodigo:setEnabled(false)
end)

thisWIN.onNewRegistry:setHandler(function ( this, sCode )
    this:getSender().txtCodigo:setText(sCode)
    this:getSender().txtCodigo:setEnabled(false)
    this:getSender().cmbActivo:setSelection(0)
    this:getSender().txtNombre:setSelection(-1, 1)
end, thisWIN)


---
--- onSaving siempre debe devolver true para que los cambios se guarden, false significa abortar:
---

thisWIN.onSaving:setHandler( function ( this )
   return true
end, thisWIN)

thisWIN.onShow:setHandler( function ( this )
   this:getSender():LoadRecord( this:getSender().DBTable:getFirstRecord() )
end, thisWIN)

----------------------------------------------------------------------------------------------------
---> thisWIN.lblCodigo thisWIN.txtCodigo

thisWIN.lblCodigo  =  Label { Name =  ( thisWIN:getName() .. '.lblCodigo' ),
  Parent = thisWIN.Panel, 
  PosX = 10 , PosY = 20,-- Width = 65, Height = 20,
  
  Text = "Codigo  :", --Font = "Courier New"
}

thisWIN.txtCodigo  = Textbox { Name =  ( thisWIN:getName() .. '.txtCodigo' ), 
  Parent = thisWIN.Panel, 
  PosX = 80 , PosY = 17, Width = 100, Height = 23, 
  --Font = "Courier New" 
}

thisWIN.txtCodigo:setEnabled(false)
thisWIN.txtCodigo.sqlField = 'CODIGO'

---< thisWIN.lblCodigo thisWIN.txtCodigo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblActivo thisWIN.txtActivo

thisWIN.lblActivo  =  Label { Name =  ( thisWIN:getName() .. '.lblActivo' ), 
  Parent = thisWIN.Panel, 
  PosX = 300, PosY = 20, Width = 75, Height = 20,
  Text = "Activo :", --Font = "Courier New"
}

thisWIN.cmbActivo  = Combobox { Name =  ( thisWIN:getName() .. '.cmbActivo' ), 
  Parent = thisWIN.Panel, 
  PosX = 380, PosY = 17, Width = 200, Height = 23, 
  Flags = CB_READONLY , Text = ''
  --Font = "Courier New", 
}

thisWIN.cmbActivo:setEnabled(false)
thisWIN.cmbActivo.sqlField = 'ACTIVO'
thisWIN.cmbActivo.sqlFieldChoices = { "S", "N" }

---< thisWIN.lblActivo thisWIN.txtActivo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblNombre thisWIN.txtNombre

thisWIN.lblNombre = Label { Name =  ( thisWIN:getName() .. '.lblNombre' ), 
  Parent = thisWIN.Panel, 
  PosX = 10 , PosY = 50, --Width = 65, Height = 20,
  Text = "Nombre  :", --Font = "Courier New"
}

thisWIN.txtNombre = Textbox { Name =  ( thisWIN:getName() .. '.txtNombre' ), 
  Parent = thisWIN.Panel, 
  PosX = 80 , PosY = 47, Width = 200, Height = 23,
  --Font = "Courier New"
}

thisWIN.txtNombre:setEnabled(false)
thisWIN.txtNombre.sqlField = 'NOMBRE'

---< thisWIN.lblNombre thisWIN.txtNombre
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblApellidos thisWIN.txtApellidos

thisWIN.lblApellidos = Label { Name =  ( thisWIN:getName() .. '.lblApellidos' ), 
  Parent = thisWIN.Panel, 
  PosX = 300, PosY = 50, --Width = 75, Height = 20,
  Text = "Apellidos :", --Font = "Courier New" 
}

thisWIN.txtApellidos = Textbox { Name =  ( thisWIN:getName() .. '.txtApellidos' ), 
  Parent = thisWIN.Panel, 
  PosX = 380, PosY = 47, Width = 200, Height = 23, 
  --Font = "Courier New"
}

thisWIN.txtApellidos:setEnabled(false)
thisWIN.txtApellidos.sqlField = 'APELLIDOS'

---< thisWIN.lblApellidos thisWIN.txtApellidos
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblCargo thisWIN.txtCargo

thisWIN.lblCargo = Label { Name =  ( thisWIN:getName() .. '.lblCargo' ), 
  Parent = thisWIN.Panel, 
  PosX = 10, PosY = 80, 
  Text = "Cargo   :", --Font = "Courier New" 
}

thisWIN.txtCargo = Textbox { Name =  ( thisWIN:getName() .. '.txtCargo' ), 
  Parent = thisWIN.Panel, 
  PosX = 80, PosY = 77, Width = 200, Height = 23, 
  --Font = "Courier New"
}

thisWIN.txtCargo:setEnabled(false)
thisWIN.txtCargo.sqlField = 'CARGO'

---< thisWIN.lblCargo thisWIN.txtCargo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblDocumento thisWIN.txtDocumento

thisWIN.lblDocumento  = Label { Name =  ( thisWIN:getName() .. '.lblDocumento' ), 
  Parent = thisWIN.Panel, 
  PosX = 300, PosY = 80, --Width = 75, Height = 20,
  Text = "Documento:", --Font = "Courier New" 
}

thisWIN.txtDocumento  = Textbox { Name =  ( thisWIN:getName() .. '.txtDocumento' ), 
  Parent = thisWIN.Panel, 
  PosX = 380, PosY = 77, Width = 200, Height = 23, 
  --Font = "Courier New"
}

thisWIN.txtDocumento:setEnabled(false)
thisWIN.txtDocumento.sqlField = 'DOCUMENTO'

---< thisWIN.lblDocumento thisWIN.txtDocumento
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblSalario thisWIN.txtSalario

thisWIN.lblSalario = Label { Name =  ( thisWIN:getName() .. '.lblSalario' ), 
  Parent = thisWIN.Panel, 
  PosX = 10, PosY = 110, 
  Text = "Salario :", --Font = "Courier New" 
}

thisWIN.txtSalario = Textbox { Name =  ( thisWIN:getName() .. '.txtSalario' ), 
  Parent = thisWIN.Panel, 
  PosX = 80, PosY = 107, Width = 200, Height = 23, 
  --Font = "Courier New", 
}

thisWIN.txtSalario:setEnabled(false)
thisWIN.txtSalario.sqlField = 'SALARIO'

---< thisWIN.lblSalario thisWIN.txtSalario
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblFecha thisWIN.txtFecha

thisWIN.lblFecha = Label { Name = ( thisWIN:getName() .. '.lblFecha' ), 
  Parent = thisWIN.Panel, 
  PosX = 300, PosY = 110, Width = 75, Height = 20,
  Text = "F. ingreso:", --Font = "Courier New" 
}

thisWIN.txtFecha = Textbox { Name = ( thisWIN:getName() .. '.txtFecha' ), 
  Parent = thisWIN.Panel, 
  PosX = 380, PosY = 107, Width = 200, Height = 23, 
  --Font = "Courier New"
}

thisWIN.txtFecha:setEnabled(false)
thisWIN.txtFecha.sqlField = 'FECHA_ING'

---< thisWIN.lblFecha thisWIN.txtFecha
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblEmail thisWIN.txtEmail

thisWIN.lblEmail  =  Label { Name = ( thisWIN:getName() .. '.lblEmail' ), 
  Parent = thisWIN.Panel, 
  PosX = 10 , PosY = 140, -- Width=65, Height = 20,
  Text = "Email  :", --Font = "Courier New"
}

thisWIN.txtEmail = Textbox { Name = ( thisWIN:getName() .. '.txtEmail' ),  
  Parent = thisWIN.Panel, 
  PosX = 80 , PosY = 137, Width = 200, Height = 23, 
  --Font = "Courier New", 
}

thisWIN.txtEmail:setEnabled(false)
thisWIN.txtEmail.sqlField = 'EMAIL'

---< thisWIN.lblEmail thisWIN.txtEmail
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblTelefono thisWIN.txtTelefono

thisWIN.lblTelefono = Label { Name = ( thisWIN:getName() .. '.lblTelefono' ),
  Parent = thisWIN.Panel, 
  PosX = 300, PosY = 140, --Width = 75, Height = 20,
  Text = "Telefono :", --Font = "Courier New"
}

thisWIN.txtTelefono = Textbox { Name = ( thisWIN:getName() .. '.txtTelefono' ),
  Parent = thisWIN.Panel, 
  PosX = 380, PosY = 137, Width = 200, Height = 23, 
  --Font = "Courier New", 
}

thisWIN.txtTelefono:setEnabled(false)
thisWIN.txtTelefono.sqlField = 'TELEFONO'

---< thisWIN.lblTelefono thisWIN.txtTelefono
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblEPS thisWIN.txtEPS

thisWIN.lblEPS = Label { Name = ( thisWIN:getName() .. '.lblEPS' ),
  Parent = thisWIN.Panel, 
  PosX = 10 , PosY = 170, --Width=65, Height = 20,
  Text = "EPS  :", --Font = "Courier New"
}

thisWIN.txtEPS = Textbox { Name = ( thisWIN:getName() .. '.txtEPS' ),
  Parent = thisWIN.Panel, 
  PosX = 80 , PosY = 167, Width = 200, Height = 23, 
  --Font = "Courier New", 
}

thisWIN.txtEPS:setEnabled(false)
thisWIN.txtEPS.sqlField = 'EPS'

---< thisWIN.lblEPS thisWIN.txtEPS
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWIN.lblAFP thisWIN.txtAFP

thisWIN.lblAFP = Label { Name = ( thisWIN:getName() .. '.lblAFP' ),
  Parent = thisWIN.Panel, 
  PosX = 300, PosY = 170, Width = 75, Height = 20, 
  Text = "AFP :", --Font = "Courier New"
}

thisWIN.txtAFP = Textbox { Name = ( thisWIN:getName() .. '.txtAFP' ),
  Parent = thisWIN.Panel, 
  PosX = 380, PosY = 167, Width = 200, Height = 23, 
  --Font = "Courier New"
}

thisWIN.txtAFP:setEnabled(false)
thisWIN.txtAFP.sqlField = 'AFP'


---< thisWIN.lblAFP thisWIN.txtAFP
----------------------------------------------------------------------------------------------------

app.addResource(App.MODULES.MAE_EMPL, function ( resID )
      thisWIN:show()  
end)

return thisWIN