---------------------------------------------------------------------------------------------------
---> thisWindow

local Form      = lide.classes.widgets.form
local Label     = lide.classes.controls.label
local Textbox   = lide.classes.controls.textbox
local Grid      = lide.classes.controls.grid
local BoxSizer  = lide.classes.boxsizer
local ComboBox  = lide.classes.controls.combobox

local thisWindow = Form:new { Name   = "searchWindow",
  Width  = 800, Height = 400, MaxWidth = 800, MaxHeight = 400,
  Style  = WIN_DEFAULT_STYLE + WIN_TOOL_WINDOW + WIN_STAY_ON_TOP,-- WIN_RESIZE_BORDER,
  Title  = "Maestro de empleados"
}

-- Function Definitions:

local f = require "forms.searchwindow_definitions"

thisWindow.AddRegistry  = f.AddRegistry
thisWindow.Fields       = f.Fields

-- Prevent Window Destruction..
thisWindow:getwxObj():Connect(wx.wxEVT_CLOSE_WINDOW, function ( event )
   --App:ExitMainLoop()
   thisWindow:setVisible(false)
end)


---< thisWindow
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> lblSearch, 

--[[local lblSearch = Label:new { Name = "lblSearch", 
   Parent = thisWindow, 
   PosX   = 10, PosY = 10,
   Text   = "BUSCAR"
}

lblSearch:setFont("Calibri", 10, "Bold")

thisWindow.lblSearch = lblSearch
]]
---< lblSearch
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> cmbSearch

--local cmbSearch = ComboBox:new { Name = "cmbSearch",
--  Parent = thisWindow, 
--  PosX   = 80, PosY = 5, 
--  --Width  = 109, Height = 23,  
--  Flags  = CB_READONLY,
--  Text = ''
--}
--
--cmbSearch:setChoices (thisWindow.Fields)
--cmbSearch:setSelection(0)
--
--thisWindow.cmbSearch = cmbSearch

---< cmbSearch
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> txtSearch
--[[
local txtSearch = Textbox:new { Name = "txtSearch",
  Parent = thisWindow,
  PosX   = 200, PosY = 6,
  Width  = 500, Height = 24,

  Text = "Codigo",
}

thisWindow.txtSearch = txtSearch

---< txtSearch
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> btnSearch

local btnSearch = Button:new { Name = "btnSearch",
  Parent = thisWindow, 
  PosX   = 700, PosY = 5,

  Text = "Buscar",
}



txtSearch:getwxObj():Connect(wx.wxEVT_KEY_UP, function ( event )
    local grdClients, grdTable = thisWindow.grdClients, thisWindow.grdClients.GridTable
    local txt, cmb   = txtSearch:getText(), cmbSearch:getText()
    local rows, cols = 0, grdTable:getNumberCols()
    
    -- Limpiamos el grid    
    grdTable:clear()
    grdTable = GridTable:new(rows, cols)
    grdClients:setTable(grdTable)
    
    -- Establecemos los nombres de las columnas
    local col_names = thisWindow.Fields
    for i = 1, #col_names do
        grdTable:setColLabelValue(i-1, col_names[i])
    end

    -- A�adimos los registros
    for _,registry in pairs(SQLT.CLIENTES:list '*') do
        if string.find(registry[cmb]:upper(), txt:upper()) then
            thisWindow:addRegistry(registry)
        end
    end
    
    -- Refrescmos el grid
    grdClients:autoSizeColumns()
    grdClients:forceRefresh()
end)

---< btnSearch
----------------------------------------------------------------------------------------------------
]]

----------------------------------------------------------------------------------------------------
---> grdClients

local grdClients = Grid:new {
  Parent = thisWindow, Name = "grdClients",
  PosX   = 0, PosY = 0,
  Width  = thisWindow:getWidth(), Height = thisWindow:getHeight()-70,
  SelectMode = GRID_SELMODE_ROWS,
}

grdClients:setDefaultCellAlignment(ALIGN_CENTRE, ALIGN_CENTRE)
grdClients:setDefaultCellAlignment(ALIGN_CENTRE, ALIGN_CENTRE)
grdClients:setDefaultCellFont("Courier New", 8)
grdClients:setRowLabelSize(23)
grdClients:setColLabelSize(23)
grdClients:getwxObj():EnableDragColSize(true)

function grdClients:OnCellDoubleClick( Row, Col )
    self:SelectRow(Row)
    local sCodigo = self.GridTable:GetValue(Row, 0)
    maempl_window:LoadEmployee(
        SQLT.CLIENTES:list('*', string.format("where Codigo = '%s'", sCodigo))[1]
    )
    self.Parent.Parent:Hide() --> Ocultamos la ventana
end

thisWindow.grdClients = grdClients

---< grdClients
----------------------------------------------------------------------------------------------------
--[[
thisWindow.Sizer = BoxSizer ( VERTICAL )  
thisWindow.Panel:setSizer( thisWindow.Sizer )

thisWindow.Panel.SizerUno = BoxSizer ( HORIZONTAL )  
thisWindow.Panel.SizerDos = BoxSizer ( HORIZONTAL )

thisWindow.Sizer:add(thisWindow.Panel.SizerUno, 0, wx.wxEXPAND + wx.wxALIGN_CENTER_HORIZONTAL + BOTTOM, 10 )
thisWindow.Sizer:add(thisWindow.Panel.SizerDos, 1, ALIGN_CENTER + EXPAND + ALL + BOTTOM, 0 )
  
thisWindow.Panel.SizerUno:add( lblSearch , 0, TOP + LEFT + RIGHT, 10)
thisWindow.Panel.SizerUno:add( cmbSearch , 0, TOP + LEFT + RIGHT, 5 )
thisWindow.Panel.SizerUno:add( txtSearch , 1, TOP + LEFT + RIGHT, 5 )
thisWindow.Panel.SizerUno:add( btnSearch , 0, TOP + LEFT + RIGHT, 4 )
thisWindow.Panel.SizerDos:add( grdClients, 1, EXPAND            , 0 )
]]
return thisWindow