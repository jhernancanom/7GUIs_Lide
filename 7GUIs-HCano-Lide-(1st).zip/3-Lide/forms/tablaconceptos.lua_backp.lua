-- 
--  thisWindow = {
--      DBTable, >>> Representa la tabla SQL asociada al formulario
--      Toolbar, >>> Representa el objeto Toolbar asociado al formulario
--
--   >>> Objetos dentro de la ventana
--
--      txtCodigo, lblCodigo, lblClase   , txtActivo, lblFactor, txtFactor,
--      lblConcepto, txtConcepto, lblContable, txtContable
--      lblEmail , txtEmail , lblTelefono , txtTelefono, 
--      lblAFP   , txtAFP   , lblEPS      , txtEPS,
--      lblFecha , txtFecha , lblSalario  , txtSalario
--   }
--
--   Funciones:
--
--   self.LoadTable( table tDatos )
--     Llena los controles del formulario con los datos que contiene 'tDatos'
--
--   table self.ToTable( table tDatos )
--     Toma los datos de los controles y retorna una tabla con los valores
--   
--   self.SetViewMode ( cons ViewMode )
--     Cambia la funcionalidad del formulario; hay dos posibilidades:
--       FORM_VIEW, FORM_EDIT
--
--   self.ClearInputs ()
--     Limpia todos los controles.


VAEForm = require 'forms.vaeform'

local thisWindow = VAEForm:new {
  Width  = 485, Height = 200,
  --Style  = WIN_DEFAULT_STYLE+ WIN_TOOL_WINDOW + WIN_STAY_ON_TOP,
  Title  = "Tabla de conceptos",
  DBTable = SQLT.CONCEPTOS
} 

--thisWindow.
thisWindow:SetMaxSize(620, 300)

-- Function Definitions:

thisWindow.onShow:setHandler(function ( ... )
    self:SetViewMode(FORM_VIEW)
    self:LoadRegistry( assert(thisWindow.DBTable:getLastRecord()) )
end)

----------------------------------------------------------------------------------------------------
---> thisWindow.Toolbar
--[[
local thisToolbar = ToolBar:new {
   Parent = thisWindow,
   Flags = TB_NODIVIDER + TB_FLAT + TB_HORIZONTAL + TB_HORZ_LAYOUT + TB_TEXT
}

enum {
  ID_NEW_REG    = lide.newid(),
  ID_EDIT_REG   = lide.newid(),
  ID_DELETE_REG = lide.newid(),
  ID_RELOAD_REG = lide.newid(),
  ID_SEARCH_REG = lide.newid(),
  ID_FIRST_REG  = lide.newid(),
  ID_BEFORE_REG = lide.newid(),
  ID_NEXT_REG   = lide.newid(),
  ID_LAST_REG   = lide.newid(),

--  NEW_RECORD    = lide.newid()
}


thisToolbar:SetImageSizes(18, 18) --> Establecemos el tamano de las imagenes de los items.

thisToolbar:AddTool(ID_NEW_REG   , "Nuevo"   , "graphics/document--plus.png")
thisToolbar:AddTool(ID_EDIT_REG  , "Editar"  , "graphics/document--pencil.png")
thisToolbar:AddTool(ID_DELETE_REG, "Borrar"  , "graphics/eraser.png")
thisToolbar:AddTool(ID_RELOAD_REG, "Recargar", "graphics/arrow-circle-315.png")
thisToolbar:AddSeparator()
thisToolbar:AddTool(ID_FIRST_REG  , "" , "graphics/arrow-stop-180.png")
thisToolbar:AddTool(ID_BEFORE_REG , "" , "graphics/arrow-skip-180.png")
thisToolbar:AddTool(ID_NEXT_REG   , "" , "graphics/arrow-skip.png")
thisToolbar:AddTool(ID_LAST_REG   , "" , "graphics/arrow-stop.png")
thisToolbar:AddTool(ID_SEARCH_REG , "Buscar" , "graphics/magnifier.png")

thisToolbar:SetToolEnabled(ID_DELETE_REG, false)

function thisToolbar:OnToolClick( nToolID, bToolStatus)  
   if not thisWindow.CURRENT_RECORD then return end --> Correcion de errores
   
   local CurrentEmployee = thisWindow.CURRENT_RECORD
   local tDatos = thisWindow:ToTable() 
   
   if (ID_NEW_REG == nToolID) then
      thisWindow.BEFORE_RECORD = thisWindow.CURRENT_RECORD
      
      local tRecord  = thisWindow.DBTable:list(thisWindow.DBTable.primarykey .. ', Codigo')
      local n, sCode = tonumber(tRecord[#tRecord][thisWindow.DBTable.primarykey]) +1
      
      sCode = "0000" .. tonumber(n)
      sCode = sCode:sub(#sCode -3, #sCode )

      thisWindow:ClearInputs()
      thisWindow:SetViewMode(FORM_EDIT)
      thisWindow.txtCodigo:SetText(sCode)
      thisWindow.cmbClase:SetSelection(0)
      thisWindow.txtConcepto:SetSelection(-1,-1)
      thisWindow:DisableToolbar ( ID_NEW_REG, ID_EDIT_REG, ID_DELETE_REG, ID_RELOAD_REG, ID_FIRST_REG, ID_BEFORE_REG, ID_NEXT_REG, ID_LAST_REG, ID_SEARCH_REG )

      thisWindow.CURRENT_RECORD = NEW_RECORD --> Para crear

   elseif ID_EDIT_REG == nToolID then
      thisWindow.BEFORE_RECORD = thisWindow.CURRENT_RECORD
      thisWindow:SetViewMode(FORM_EDIT)
      
      thisWindow:DisableToolbar ( ID_NEW_REG, ID_EDIT_REG, ID_FIRST_REG, ID_BEFORE_REG, ID_NEXT_REG, ID_LAST_REG, ID_SEARCH_REG )

    elseif ( ID_DELETE_REG == nToolID ) then
        thisWindow:SetViewMode(FORM_VIEW)
        if YES == MessageBox("Seguro desea eliminar el registro?", "Maestro de empleados", ICON_EXCLAMATION + YES_NO ) then
            thisWindow.DBTable:delete( thisWindow.CURRENT_RECORD.recordid )
            thisToolbar:OnToolClick( ID_BEFORE_REG ) 
        else
            thisWindow:SetViewMode(FORM_EDIT)
        end
   
   elseif (ID_RELOAD_REG == nToolID) then
      thisWindow:LoadRegistry( thisWindow.CURRENT_RECORD )
      
      local nrid = tonumber(thisWindow.CURRENT_RECORD.recordid)
      
      if ( nrid == 1 ) then
         thisWindow.Toolbar:SetToolEnabled(ID_FIRST_REG, false)
      elseif ( nrid == tonumber(thisWindow.DBTable:getLastRecord().recordid ) )then
         thisWindow.Toolbar:SetToolEnabled(ID_LAST_REG , false)
      end

   elseif ID_FIRST_REG == nToolID then
      local record = thisWindow.DBTable:getFirstRecord()
      thisWindow:LoadRegistry(record)
      thisWindow.CURRENT_RECORD = record

      thisWindow.Toolbar:SetToolEnabled(ID_FIRST_REG, false)
      thisWindow.Toolbar:SetToolEnabled(ID_LAST_REG , true)

   elseif ID_BEFORE_REG == nToolID then
         local CURRENT_RECORD = tonumber(thisWindow.CURRENT_RECORD.recordid)
         
         if CURRENT_RECORD <= 1 then return end --> break
         local  kit
         -- Utilizamos un loop repeat por si eliminamos registros en la base de datos no haya problemas
         repeat CURRENT_RECORD = CURRENT_RECORD -1
            kit = thisWindow.DBTable:getRecord( CURRENT_RECORD )
         until kit
         
         thisWindow:LoadRegistry(kit)
         
         if kit.recordid == thisWindow.DBTable:getFirstRecord().recordid then
          thisWindow.Toolbar:SetToolEnabled(ID_FIRST_REG, false)
         end
         
         if ( kit.recordid ~= thisWindow.DBTable:getLastRecord().recordid ) then
          thisWindow.Toolbar:SetToolEnabled(ID_LAST_REG, false)         
         end

      thisWindow.CURRENT_RECORD = kit
      thisWindow.Toolbar:SetToolEnabled(ID_LAST_REG, true)

   elseif ID_NEXT_REG == nToolID then
         local CURRENT_RECORD, kit = tonumber(thisWindow.CURRENT_RECORD.recordid)
         if CURRENT_RECORD +1 > tonumber(thisWindow.DBTable:getLastRecord().recordid) then return end --> break  

         repeat CURRENT_RECORD = CURRENT_RECORD +1
            kit = thisWindow.DBTable:getRecord( CURRENT_RECORD )
         until kit
        
         thisWindow:LoadRegistry(kit)
                  
         if ( kit.recordid == thisWindow.DBTable:getLastRecord().recordid ) then
            thisWindow.Toolbar:SetToolEnabled(ID_LAST_REG, false)
         end

         thisWindow.CURRENT_RECORD = kit

         thisWindow.Toolbar:SetToolEnabled(ID_BEFORE_REG, true)
         thisWindow.Toolbar:SetToolEnabled(ID_FIRST_REG, true)
  elseif ID_LAST_REG == nToolID then
      thisWindow:LoadRegistry( thisWindow.DBTable:getLastRecord() )
      thisWindow.CURRENT_RECORD = thisWindow.DBTable:getLastRecord()
      thisWindow.Toolbar:SetToolEnabled(ID_LAST_REG , false)
      thisWindow.Toolbar:SetToolEnabled(ID_FIRST_REG, true)
      
   elseif ID_SEARCH_REG == nToolID then
      --search_window.Fields = thisWindow.Inputs
      search_window.cmbSearch:SetChoices( SQLT.CONCEPTOS:getcolnames() )
      search_window:show()
      local tabla = GridTable:new ( "select CODIGO, DEV_DED, DESCRIPCIO, CONTABLE from TABLA_CONCEPTOS", "./testing.db", "sqlite3" )
       
      search_window.grdClients:SetTable (tabla, true, true)  --> gridtable, bool auto_size, bool takeOwnership, cons selmode 
   end
end

thisWindow.Toolbar = thisToolbar

---< thisWindow.Toolbar
----------------------------------------------------------------------------------------------------
]]

----------------------------------------------------------------------------------------------------
---> thisWindow.lblCodigo thisWindow.txtCodigo

local lblCodigo  =  Label  { 
  Parent = thisWindow, Name = "lblCodigo",
  PosX = 10 , PosY = 20, Width = 65, Height = 20,
  Text = "Codigo  :", Font = "Courier New"
}

local txtCodigo  = Textbox { 
  Parent = thisWindow, 
  PosX = 80 , PosY = 17, Width = 130, Height = 23, 
  Font = "Courier New" 
}

thisWindow.lblCodigo = lblCodigo
thisWindow.txtCodigo = txtCodigo

---< thisWindow.lblCodigo thisWindow.txtCodigo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWindow.lblClase thisWindow.txtActivo

local lblClase  =  Label  {
  Parent = thisWindow, 
  PosX = 250, PosY = 20, Width = 75, Height = 20,
  Text = "Clase    :", Font = "Courier New"
}

local cmbClase  = ComboBox { 
  Parent = thisWindow, 
  PosX = 330, PosY = 17, Width = 130, Height = 23, 
  Font = "Courier New", Flags = CB_READONLY ,
  Choices = { "Neutro", "Devengado", "Deducido" }
}

thisWindow.lblClase = lblClase
thisWindow.cmbClase = cmbClase


---< thisWindow.lblClase thisWindow.txtActivo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWindow.lblConcepto thisWindow.txtConcepto

local lblConcepto = Label { 
  Parent = thisWindow, 
  PosX = 10 , PosY = 50, Width = 65, Height = 20,
  Text = "Concepto:", Font = "Courier New"
}

local txtConcepto  = Textbox { 
  Parent = thisWindow, 
  PosX = 80 , PosY = 47, Width = 130, Height = 23,
  Font = "Courier New"
}

thisWindow.lblConcepto = lblConcepto
thisWindow.txtConcepto = txtConcepto

---< thisWindow.lblConcepto thisWindow.txtConcepto
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWindow.lblContable thisWindow.txtContable

local lblContable  =  Label  { 
  Parent = thisWindow, 
  PosX = 250, PosY = 50, Width = 75, Height = 20,
  Text = "Contable :", Font = "Courier New" 
}

local txtContable  = Textbox { 
  Parent = thisWindow, 
  PosX = 330, PosY = 47, Width = 130, Height = 23, 
  Font = "Courier New"
}

thisWindow.lblContable = lblContable
thisWindow.txtContable = txtContable

---< thisWindow.lblContable thisWindow.txtContable
----------------------------------------------------------------------------------------------------
--[[
local btnCancel = Button:new {
   Parent = thisWindow, Name = "thisWindow.btnCancel",
   PosX = 249, PosY = 105,
   Text = "Cancelar"
}

btnCancel:SetVisible(false)

function btnCancel:OnClick( ... )
    thisWindow:SetViewMode(FORM_VIEW)
    thisWindow.btnCancel:SetVisible(false)
    thisWindow.btnSave:SetVisible(false)
   
    thisWindow:LoadRegistry( thisWindow.BEFORE_RECORD )

    thisWindow:EnableToolbar ( ID_NEW_REG, ID_RELOAD_REG, ID_FIRST_REG, ID_BEFORE_REG, ID_NEXT_REG, ID_LAST_REG, ID_SEARCH_REG )
    thisWindow.Toolbar:OnToolClick(ID_RELOAD_REG) --> RELOAD
end

local btnSave = Button:new {
   Parent = thisWindow, Name = "thisWindow.btnSave",
   PosX = 373, PosY = 105,
   Text = "Guardar"
}

btnSave:SetVisible(false)

function btnSave:OnClick( ... )
    
    local tDatos = thisWindow:ToTable() 
    
    if   thisWindow.cmbClase:GetSelection()   == 0 then
        tDatos.DEV_DED = 'N' 
    elseif thisWindow.cmbClase:GetSelection() == 1 then
        tDatos.DEV_DED = '+'
    elseif thisWindow.cmbClase:GetSelection() == 2 then
        tDatos.DEV_DED = '-'
    end

    local tosave = {
         CODIGO     = tostring(tDatos.CODIGO),
         DESCRIPCIO = tostring(tDatos.DESCRIPCIO),
         DEV_DED    = tostring(tDatos.DEV_DED),
         CONTABLE   = tostring(tDatos.CONTABLE)
    }

    if (thisWindow.CURRENT_RECORD == NEW_RECORD) then
        thisWindow.DBTable:insert (tosave)
        thisWindow:LoadRegistry( thisWindow.DBTable:getLastRecord() )
    else
        thisWindow.DBTable:update( thisWindow.CURRENT_RECORD.recordid, tosave)
    end
    thisWindow:SetViewMode(FORM_VIEW)
    thisWindow:EnableToolbar ( ID_NEW_REG, ID_RELOAD_REG, ID_FIRST_REG, ID_BEFORE_REG, ID_NEXT_REG, ID_LAST_REG, ID_SEARCH_REG )
end
]]
--thisWindow.btnCancel = btnCancel
--thisWindow.btnSave   = btnSave


local VAEForm = require "forms.vaeform"

local thisWindow = VAEForm:new { Name = 'tblconc',
    Title = 'Tabla de conceptos',
    DBTable = SQLT.CONCEPTOS,
    
    Width = 500, Height = 200,
}

local function onshow_handler ( )
   this:getSender().btnSave:SetPosition  (443 -70, 100)
   this:getSender().btnCancel:SetPosition(329 -70, 100)
   this:getSender():LoadRecord ( this:getSender().DBTable:getFirstRecord() )
   this:getSender():SetViewMode(FORM_VIEW)
end

thisWindow.onShow:setHandler( onshow_handler, thisWindow )

thisWindow.onNewRegistry:setHandler( function ( sCode )
    this:getSender().txtCodigo:SetText(sCode)
end, thisWindow)

----------------------------------------------------------------------------------------------------
---> thisWindow.lblCodigo thisWindow.txtCodigo

thisWindow.lblCodigo  =  Label  { Name =  ( thisWindow.Name .. '.lblCodigo' ),
  Parent = thisWindow.Panel, 
  PosX = 10 , PosY = 20, Width = 65, Height = 20,
  Text = "Codigo  :", Font = "Courier New"
}

thisWindow.txtCodigo  = Textbox { Name =  ( thisWindow.Name .. '.txtCodigo' ),
  Parent = thisWindow.Panel, 
  PosX = 80 , PosY = 17, Width = 130, Height = 23, 
  Font = "Courier New" 
}

thisWindow.txtCodigo.sqlField = 'CODIGO'

---< thisWindow.lblCodigo thisWindow.txtCodigo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWindow.lblClase thisWindow.txtActivo

thisWindow.lblClase  =  Label   {  Name =  ( thisWindow.Name .. '.lblClase' ),
  Parent = thisWindow.Panel, 
  PosX = 250, PosY = 20, Width = 75, Height = 20,
  Text = "Clase    :", Font = "Courier New"
}

thisWindow.cmbClase  = ComboBox { Name =  ( thisWindow.Name .. '.cmbClase' ),
  Parent = thisWindow.Panel,
  PosX = 330, PosY = 17, Width = 130, Height = 23, 
  Font = "Courier New", Flags = CB_READONLY ,
}

thisWindow.cmbClase.sqlField = 'DEV_DED'
thisWindow.cmbClase.sqlFieldChoices = { "Neto", "Devengado", "Deducido" } 

---< thisWindow.lblClase thisWindow.txtActivo
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWindow.lblConcepto thisWindow.txtConcepto

thisWindow.lblConcepto = Label { Name =  ( thisWindow.Name .. '.lblConcepto' ),
  Parent = thisWindow.Panel,
  PosX = 10 , PosY = 50, Width = 65, Height = 20,
  Text = "Concepto:", Font = "Courier New"
}

thisWindow.txtConcepto  = Textbox { Name =  ( thisWindow.Name .. '.txtConcepto' ),
  Parent = thisWindow.Panel,
  PosX = 80 , PosY = 47, Width = 130, Height = 23,
  Font = "Courier New"
}

thisWindow.txtConcepto.sqlField = 'DESCRIPCIO'

---< thisWindow.lblConcepto thisWindow.txtConcepto
----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------
---> thisWindow.lblContable thisWindow.txtContable

thisWindow.lblContable  =  Label  { Name =  ( thisWindow.Name .. '.lblContable' ),
  Parent = thisWindow.Panel,
  PosX = 250, PosY = 50, Width = 75, Height = 20,
  Text = "Contable :", Font = "Courier New" 
}

thisWindow.txtContable  = Textbox { Name =  ( thisWindow.Name .. '.txtContable' ),
  Parent = thisWindow.Panel,
  PosX = 330, PosY = 47, Width = 130, Height = 23, 
  Font = "Courier New"
}

thisWindow.txtContable.sqlField = 'CONTABLE'

---< thisWindow.lblContable thisWindow.txtContable
----------------------------------------------------------------------------------------------------
local res_func = function ( resID )
      thisWindow:show()  
end

App.AddResource(App.MODULES.TBL_CONCEPTOS, res_func)

return thisWindow