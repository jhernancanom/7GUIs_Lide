-- VAEForm: View And Edit Form28
-- VAEForm.onToolClick = VAEForm.Toolbar.onToolClick
-- VAEForm:onNewRegistry

-- string VAEForm.ViewerCols -- columnas que se muestradn en el visor de search
--xEvent = require 'xevent'

-- event onSaving -- ants de guardar en la bd (SI EL HANDLER DE ESTE ENVENTO DEVUELVE false, onsaved no se ejecuta)
-- event ººonsaved  -- dsps de guardar en la bd (si el handler de onsaving develve false este no se ejecuta)

-- .CURRENTRECORD

-- Cargar las clases:
local VAEForm 
local Form      = lide.classes.widgets.form
local Toolbar   = lide.classes.controls.toolbar
local Event     = lide.classes.event
local GridTable = lide.classes.gridtable
local Label     = lide.classes.controls.label

-- Cargar las funciones:
local newID    = lide.core.base.newid
local isObject = lide.core.base.isobject
local isNumber = lide.core.base.isnumber
local isString = lide.core.base.isstring

-- Importar las librerias:
local check = lide.core.base.check

-- Definir las constantes:
--- No utilizar enum, genera errores en tiempo de ejecucion.

ID_NEW_RECORD    = newID()--,
ID_EDIT_RECORD   = newID()--,
ID_DELETE_RECORD = newID()--,
ID_RELOAD_RECORD = newID()--,
ID_SEARCH_RECORD = newID()--,
ID_FIRST_RECORD  = newID()--,
ID_BEFORE_RECORD = newID()--,
ID_NEXT_RECORD   = newID()--,
ID_LAST_RECORD   = newID()--,
NEW_RECORD       = newID()--,

FORM_VIEW        = false--,
FORM_EDIT        = true --,
APP_WORK_DIR     = app.getWorkDir()

-- Definicion de la clase VAEForm:

local VAEForm = class 'VAEForm' : subclassof 'Object'
    
    : global(false)
    
VAEForm.FORM_VIEW = FORM_VIEW
VAEForm.FORM_EDIT = FORM_EDIT

-- Definicion de funciones

ONTOOLCLICK_HANDLER = function ( this, nToolID, bToolStatus)  
    isNumber(nToolID)
    local self = this:getSender()
    --self.onBarSelect:call( nToolID ) 
    if tonumber (self.CURRENT_RECORD) then
        self.CURRENT_RECORD = self.DBTable:getLastRecord()        
    end

    if not self.CURRENT_RECORD then return error ('NO .CURRENT_RECORD') end --> Correcion de errores

    local LastRecord  = self.DBTable:getLastRecord()
    local FirstRecord = self.DBTable:getFirstRecord()
    local PrimaryKey  = self.DBTable.primarykey
    local CurrentRecord   = self.CURRENT_RECORD
    local CurrentRecordID = self.CURRENT_RECORD[PrimaryKey]
    local LastRecordID    = LastRecord[PrimaryKey]
    local nextRecord
    
    

    if (ID_NEW_RECORD == nToolID) then
        self:ClearInputs()
        self:setViewMode(FORM_EDIT)
        self.Toolbar:setToolEnabled(ID_RELOAD_RECORD, false)
        self.Toolbar:setToolEnabled(ID_DELETE_RECORD, false)

        self.LAST_RECORD = table.copy(self.CURRENT_RECORD) -- Creamos una copia de la tabla en la memoria para poder cargarla luego en caso de Cancelar
        
        -- --> En esta parte le asignamos un numero a CURRENT_RECORD 
        -- -- (Solo para reconocer que queremos añadir un nuevo registro)
        self.CURRENT_RECORD = NEW_RECORD 
        
        -- -- Generamos el evento OnNewRegistry:
        local sCode = '0000' .. tonumber( LastRecord[PrimaryKey] ) +1
        sCode = sCode:sub(#sCode -3, #sCode )
        
        self.onNewRegistry:call( sCode )
    elseif ID_EDIT_RECORD == nToolID then   
        self.LAST_RECORD = table.copy(self.CURRENT_RECORD) -- Creamos una copia de la tabla en la memoria para poder cargarla luego en caso de Cancelar
        self:setViewMode(FORM_EDIT)
        self.EDITING = true
        self.onEditRegistry:call()

    elseif ( ID_DELETE_RECORD == nToolID ) then
        if YES == lide.core.base.messagebox('Seguro desea eliminar el registro?', 'Maestro de empleados', ICON_EXCLAMATION + YES_NO ) then

            self.DBTable:delete( CurrentRecordID )

            self.EDITING = false
            self.Toolbar.onToolClick:call(ID_RELOAD_RECORD) -- RECARGAMOS REGISTROS DESDE LA BD
            self:setViewMode(FORM_VIEW)

            local n = CurrentRecordID repeat
                nextRecord = self.DBTable:getRecord( n )  n = n -1
            until nextRecord

        end
    
    elseif (ID_RELOAD_RECORD == nToolID) then        
        nextRecord = self.DBTable:getRecord( CurrentRecordID )
        self:LoadRecord( nextRecord )
    elseif ID_FIRST_RECORD == nToolID then
        local n = 0 repeat n = n +1
            nextRecord = self.DBTable:getRecord( n ) 
        until nextRecord
        
    elseif ID_BEFORE_RECORD == nToolID then
        
        local n = CurrentRecordID repeat n = n -1
            nextRecord = self.DBTable:getRecord( n ) 
        until nextRecord or n < tonumber(0)

    elseif ID_NEXT_RECORD == nToolID then
        local n = CurrentRecordID repeat n = n +1
            nextRecord = self.DBTable:getRecord( n ) 
        until nextRecord or n > tonumber(LastRecordID)

    elseif ID_LAST_RECORD == nToolID then
        nextRecord = self.DBTable:getLastRecord()
        
    elseif ID_SEARCH_RECORD == nToolID then
        --local query   = 'select %s from %s'
        --local sqlCols = self.ViewerCols

        self.Viewer:show()
        --self.Viewer.GridTable = GridTable:new ( query:format(sqlCols, self.DBTable.tablename), self.DBTable.database, 'sqlite3' )
        --self.Viewer.grdClients:setTable(self.Viewer.GridTable, false, false)

        --self.Viewer.grdClients:autoSizeColumns( false )
    end
    
    if ( nToolID ~= ID_NEW_RECORD ) and ( nToolID ~= ID_EDIT_RECORD ) then
        if not nextRecord or self.EDITING then return end
        
        self.Toolbar:setToolEnabled(ID_FIRST_RECORD , nextRecord[PrimaryKey] ~= FirstRecord[PrimaryKey])
        self.Toolbar:setToolEnabled(ID_LAST_RECORD  , nextRecord[PrimaryKey] ~= LastRecord [PrimaryKey])

        self:LoadRecord( nextRecord )
    end
end



-- Defincion del constructor de la clase:

function VAEForm:VAEForm ( fields )
    check.fields {
        'string Name',
        'table SaveButton', 'table CancelButton',
    }

    public {
        onShow, onSaving, onSaved, onNewregistry, onEditregistry, onBarSelect,
        Toolbar, Panel,

        SaveButton   = fields.SaveButton,
        CancelButton = fields.CancelButton,
        
        ViewerCols   = fields.ViewerCols or '*',
        Lobj = '.none.'
    }

    -- Llamamos al constructor de la super-clase Object
    self.super : init ( fields.Name )

    self.Lobj = Form : new { 
        Name   = fields.Name,
        Title  = fields.Title,

        Width  = fields.Width or 620, Height = fields.Height or 300,
        Style  = WIN_DEFAULT_STYLE + WIN_TOOL_WINDOW + WIN_STAY_ON_TOP,
    }

    if lide.platform.getOSName() == 'Windows' then
        self.Lobj:setWidth (self.Lobj:getWidth()  +10 )
        self.Lobj:setHeight(self.Lobj:getHeight() +30 )
    end

    self.Lobj.onClose:setHandler( function ( thisEVT )
        self.Lobj:setVisible(false)
        self:ClearInputs()

    end, self ) -- VAEForm as the Event Sender.

    self.Lobj.onShow:setHandler( function ( thisEVT, SHOWING )
        if SHOWING then
            self.btnCancel.onClick:call()
        else
            self.Lobj:setVisible(false)
            self:ClearInputs()
        end
    end, self ) -- VAEForm as the Event Sender.
    
    self.DBTable = fields.DBTable

    self.CURRENT_RECORD = self.DBTable:getFirstRecord()
    

    self.LAST_RECORD    = nil    --

    self.onShow         = Event:new ( self:getName() .. '.onShow'        , self )   
    self.onSaved        = Event:new ( self:getName() .. '.onSaved'       , self )
    self.onSaving       = Event:new ( self:getName() .. '.onSaving'      , self )
    self.onBarSelect    = Event:new ( self:getName() .. '.onBarSelect'   , self )
    self.onNewRegistry  = Event:new ( self:getName() .. '.onNewRegistry' , self )
    self.onEditRegistry = Event:new ( self:getName() .. '.onEditRegistry', self )
    self.onToolClick    = Event:new ( self:getName() .. '.onToolClick'   , self )
    self.onToolClick:setHandler ( ONTOOLCLICK_HANDLER ) --> vaeform.ontoolclick

--    table.foreach(self, print)

    self.DBTable = fields.DBTable
    
    --self.Viewer  = dofile 'forms/searchwindow.lua'
    --self.Viewer:setTitle( 'Visor - ' .. self.Lobj:getTitle() )
    
    self.Viewer = require 'forms.viewform' : new {
        Name = self:getName()..'.formView', Title = 'Visor - '..self.Lobj:getTitle(),

        Width = 600, Height = 300,

        ShowColumns = fields.ViewerCols, --'CODIGO, ACTIVO, DOCUMENTO, NOMBRE, APELLIDOS, CARGO, AFP, EPS, SALARIO, EMAIL',
        
        DBTable  = fields.DBTable,
        Database = fields.DBTable:getDBName(),
        SQLTable = fields.DBTable:getName(),
    }

    io.stdout:write(('[%s]: %s'):format( self.Viewer:getWidgetType(), self:getName()..'\n'))

	self.Lobj:setMaxSize(620, 300)
    
    self.Panel = self.Lobj.Panel

    self.Toolbar = Toolbar:new { 
        Parent = self.Lobj, Name = self.Lobj:getName()..'.Toolbar',
        Flags = 0 --TB_NODIVIDER + TB_FLAT + TB_HORIZONTAL + TB_HORZ_LAYOUT + TB_TEXT
    }

    self.Toolbar:setImageSizes(18, 18) --> Establecemos el tamano de las imagenes de los items.
    self.Toolbar:addTool(ID_NEW_RECORD    , 'Nuevo'   , APP_WORK_DIR .. '/imgs/document--plus.png')
    self.Toolbar:addTool(ID_EDIT_RECORD   , 'Editar'  , APP_WORK_DIR .. '/imgs/document--pencil.png')
    self.Toolbar:addTool(ID_DELETE_RECORD , 'Borrar'  , APP_WORK_DIR .. '/imgs/eraser.png')
    self.Toolbar:addTool(ID_RELOAD_RECORD , 'Recargar', APP_WORK_DIR .. '/imgs/arrow-circle-315.png')
    self.Toolbar:addSeparator()
    self.Toolbar:addTool(ID_FIRST_RECORD  , ''        , APP_WORK_DIR .. '/imgs/arrow-stop-180.png')
    self.Toolbar:addTool(ID_BEFORE_RECORD , ''        , APP_WORK_DIR .. '/imgs/arrow-skip-180.png')
    self.Toolbar:addTool(ID_NEXT_RECORD   , ''        , APP_WORK_DIR .. '/imgs/arrow-skip.png')
    self.Toolbar:addTool(ID_LAST_RECORD   , ''        , APP_WORK_DIR .. '/imgs/arrow-stop.png')
    self.Toolbar:addTool(ID_SEARCH_RECORD , 'Buscar'  , APP_WORK_DIR .. '/imgs/magnifier.png')

    self.Toolbar:setToolEnabled(ID_FIRST_RECORD , false)    
    self.Toolbar:setToolEnabled(ID_DELETE_RECORD, false)    
    
    self.Toolbar.onToolClick:setHandler( function ( event, nToolID, bToolStatus )
        self.onBarSelect:call( nToolID )
        self.onToolClick:call( nToolID, bToolStatus )
    end )

    self.Toolbar:setToolEnabled(ID_FIRST_RECORD, false)

    
    self.imgStatus = Image:new {
        Parent = self.Lobj, Name = self:getName()..'.imgStatus',
            
        PosX = 0,
        PosY = self.Lobj:getHeight() -45,

        Filename = 'imgs/status.png',
    }

    self.lblStatus = Label:new {
        Parent = self.Lobj, Name = 'self.lblStatus',
            
        PosX = 18,
        PosY = self.Lobj:getHeight() - 43,

        Text = 'database: online',
    }

    self.lblStatus:setFont( 'Droid Sans Mono', 7)

    ----------------------------------------------------------------------------------------------------
    ---> VAEForm.btnCancel

    self.btnCancel = Button:new {
        Parent = self.Lobj, Name = 'VAEForm.btnCancel',
            
        PosX = self.CancelButton.PosX or 379,
        PosY = self.CancelButton.PosY or 200,

        Text = 'Cancelar', Visible = false,
    }

    self.btnCancel:setVisible(false)
    self.btnCancel.vaeform = self

    self.btnCancel.onClick:setHandler(function ( this )
        local Sender = self

        Sender:setViewMode(FORM_VIEW)

        Sender.btnCancel:setVisible(false)
        Sender.btnSave:setVisible(false)

        Sender.EDITING = false
        Sender.Toolbar.onToolClick:call(ID_RELOAD_RECORD) -- RECARGAMOS REGISTROS DESDE LA BD
    end)

    ---< VAEForm.btnCancel
    ----------------------------------------------------------------------------------------------------

    ----------------------------------------------------------------------------------------------------
    ---> VAEForm.btnSave

    self.btnSave = Button:new {
        Parent = self.Lobj, Name = 'VAEForm.btnSave',
        --PosX = 493, PosY = 200,

        PosX = self.SaveButton.PosX or 493,
        PosY = self.SaveButton.PosY or 200,
        

        Text = 'Guardar'
    }

    self.btnSave:setVisible(false)

    self.btnSave.vaeform = self

    self.btnSave.onClick:setHandler(function ( this )
        local Parent = self
        local CurrentRecord   = Parent.CURRENT_RECORD

        local tDatos = Parent:ToTable() -- Obtenemos los datos de los inputs

        -- Generamos el evento onSaving (antes de guardar los datos)
        --

        local Save = Parent.onSaving:call( tDatos, CurrentRecord )

        if Save then
            if (CurrentRecord == NEW_RECORD) then
                for k,v in pairs(tDatos) do
                   str = (str or '' ) ..  k ..', ' .. v
                end

                Parent.DBTable:insert ( tDatos )
                
                Parent:LoadRecord ( Parent.DBTable:getLastRecord() )

            else
                Parent.DBTable:update( CurrentRecord[Parent.DBTable.primarykey], tDatos )
            end
        
            Parent.EDITING = false
            Parent.Toolbar.onToolClick:call (ID_RELOAD_RECORD) -- RECARGAMOS REGISTROS DESDE LA BD

            Parent:setViewMode(FORM_VIEW)
        
            -- Generamos el evento onSaved (despues de guardar los datos)
            --
            Parent.onSaved:call( tDatos )
        else
            -- No guarda
        end
    end, self.btnSave)

    ---< VAEForm.btnSave
    ----------------------------------------------------------------------------------------------------
end

function VAEForm:show( bShow )
    self.onShow:call( true ) --> OnShow VAEForm
    self.Lobj:show( bShow )
end


function VAEForm:ToTable( )
	local ctrlText
    local t = {} for _, obj in pairs(self) do
        if lide.core.base.type(obj) == 'object' and obj.sqlField then
            ctrlText = tostring(obj:getText() or '')
            t[obj.sqlField] = ctrlText or ''
        end
    end

    return t
end

function VAEForm:ClearInputs( ... )
	for _, nameobj in pairs(self) do
        if lide.core.base.type(nameobj) == 'object' and nameobj.sqlField then
            nameobj:setText('')
        end
   	end
end


function VAEForm:setViewMode( ViewMode )
    local bButtons
    
    if ViewMode == VAEForm.FORM_EDIT then 
        self.Toolbar:setToolEnabled(ID_DELETE_RECORD, true)
        self.Toolbar:setToolEnabled(ID_NEW_RECORD , false)
        self.Toolbar:setToolEnabled(ID_EDIT_RECORD, false)
        
        self.Toolbar:setToolEnabled(ID_RELOAD_RECORD, true) 

        self.Toolbar:setToolEnabled(ID_FIRST_RECORD , false)
        self.Toolbar:setToolEnabled(ID_BEFORE_RECORD, false)
        self.Toolbar:setToolEnabled(ID_NEXT_RECORD  , false)
        self.Toolbar:setToolEnabled(ID_LAST_RECORD  , false)
        self.Toolbar:setToolEnabled(ID_SEARCH_RECORD, false)
        
    elseif ViewMode == VAEForm.FORM_VIEW then
        self.Toolbar:setToolEnabled(ID_NEW_RECORD , true)

        self.Toolbar:setToolEnabled(ID_DELETE_RECORD, false)
        self.Toolbar:setToolEnabled(ID_EDIT_RECORD, true)
        self.Toolbar:setToolEnabled(ID_RELOAD_RECORD, true) 

        self.Toolbar:setToolEnabled(ID_BEFORE_RECORD, true)
        self.Toolbar:setToolEnabled(ID_NEXT_RECORD  , true)
        self.Toolbar:setToolEnabled(ID_SEARCH_RECORD, true)
    end
    
    self.btnCancel:setVisible(ViewMode)
    self.btnSave:setVisible  (ViewMode)

    local tObjects = self for _, nameobj in pairs(tObjects) do
        if lide.core.base.type(nameobj) == 'object' and nameobj.sqlField then
            nameobj:setEnabled(ViewMode)
            -- if nameobj:getObjectType() == 'ComboBox' then
            --     if (ViewMode == FORM_VIEW) then
            --         nameobj:setReadOnly(true)
            --     elseif (ViewMode == FORM_EDIT) then
            --         nameobj:setReadOnly(false)
            --     end
            -- end
        end
    end

   self.ViewMode = ViewMode -- Guardar valor
end

function VAEForm:LoadRecord( tRecord )
   
    if not lide.core.base.type(tRecord) == 'table' then error ('La tabla no es correcta',2 ) end

    for _, inpObject in pairs(self) do
        if lide.core.base.type(inpObject) == 'object' and inpObject.sqlField then  
            
            if inpObject:class():name() == 'Combobox' then
                inpObject:setChoices( inpObject.sqlFieldChoices )

                inpObject:setSelection(                
                    inpObject:findItem(tRecord[inpObject.sqlField] or '', true) 
                )
            else
                if not tRecord[inpObject.sqlField] then
                    --lide.core.error.lperr(inpObject, inpObject.sqlField)
                    --lide.core.error.lperr('no record')
                else
                    inpObject:setText(tostring(tRecord[inpObject.sqlField]) or '')
            
                end
            end
        end
    end

    self.CURRENT_RECORD = tRecord
end

function VAEForm:Close( ... )
   self.wxObj:Close()
   self.onClose:call( ... ) 
end


return VAEForm

