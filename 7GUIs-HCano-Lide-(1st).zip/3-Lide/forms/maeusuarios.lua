/--require 'modules.init_databases'

--VAEForm = require 'forms.vaeform'

tW = Window:new {  
  --DBTable = SQLT.USERS,
  
--  ViewerCols = '*',

  --SaveButton   = { PosX = 240, PosY = 240 },
  --CancelButton = { PosX = 280, PosY = 280 },
}

lbUsers = ListBox:new {
    Parent = tW,
    PosX = 10, PosY = 10,
    Width = 150, Height = 240,
    
    Choices = {
        'admin',
        'hernan',
        'jovita',
        'dario'
    }
}

lblUser = Label:new   { PosX = 200, PosY = 15, Text = 'Usuario:' }
txtUser = Textbox:new { PosX = 280, PosY = 12, }

lblName = Label:new   { PosX = 200, PosY = 45, Text = 'Nombre largo:' }
txtName = Textbox:new { PosX = 280, PosY = 42, }

lblRango = Label:new   { PosX = 200, PosY = 75, Text = 'Rango:' }
cmbRango = ComboBox:new { PosX = 280, PosY = 72, }

lblPass = Label:new   { PosX = 200, PosY = 105, Text = 'Passwrd:' }
txtPass = Textbox:new { PosX = 280, PosY = 102, }

lblRePass = Label:new   { PosX = 200, PosY = 135, Text = 'Rep Passwrd:' }
txtRePass = Textbox:new { PosX = 280, PosY = 132, }

btnCancel = Button:new   { PosX = 200, PosY = 165, Text = 'Cancelar' }
btnSave   = Button:new   { PosX = 300, PosY = 165, Text = 'Guardar' }

tW:show()

		local thisTB = ToolBar:new { 
			Parent = self,
			Flags = TB_NODIVIDER + TB_FLAT + TB_HORIZONTAL + TB_HORZ_LAYOUT + TB_TEXT
		}

		thisTB:SetImageSizes(18, 18) --> Establecemos el tamano de las imagenes de los items.

		thisTB:AddTool(ID_NEW_RECORD    , "Nuevo"   , "graphics//document--plus.png")
		thisTB:AddTool(ID_EDIT_RECORD   , "Editar"  , "graphics//document--pencil.png")
		thisTB:AddTool(ID_DELETE_RECORD , "Borrar"  , "graphics//eraser.png")
		thisTB:AddTool(ID_RELOAD_RECORD , "Recargar", "graphics//arrow-circle-315.png")
		thisTB:AddSeparator()
    thisTB:AddTool(ID_RELOAD_RECORD , "Editar permisos", "graphics//arrow-circle-315.png")