-- lnomina/forms/windmain.lua
--- Ventana 
--- 2016/05/14

-- Importar clases necesarias
local Form     = lide.classes.widgets.form
local Label    = lide.classes.controls.label
local TextBox  = lide.classes.controls.textbox
local ComboBox = lide.classes.controls.combobox
local Button   = lide.classes.controls.button

local formHistNomina = require 'forms.viewform' :new {
   Name = 'frmListMovNomina', Title = 'Listado de movimientos de nómina',

   Width = 900, Height = 300,

   ShowColumns = 'QUINCENA, CEDULA, DESCRIPCIO, DEV_DED, ADMORA, VALOR, DIAS',
   
   Database = 'testing.db',

   SQLTable = 'TABLA_NOMHIST',
   
   -- Driver = DB_MONGODB DB_SQLITE3 DB_MARIADB DB_MYSQL
   DefaultTools = false
}

formHistNomina.Grid:autoSize()

local lblPeriodoIni = lide.classes.controls.label:new{ 
	Parent = formHistNomina.Toolbar, 
	Name = 'lblPeriodoIni', 
	Text = ' Inicial:  ',
	Width = 45, Height = 15,
}

local txtPeriodoIni = lide.classes.controls.textbox:new { 
	Parent = formHistNomina.Toolbar, 
	Name = 'txtPeriodoIni', 
	Text = '',
	Width = 75,
}

local lblPeriodoFin = lide.classes.controls.label:new {
	Parent = formHistNomina.Toolbar, 
	Name = 'lblPeriodoFin', 
	Text = '   Final:  ',
	Width = 45, Height = 15,
}

local txtPeriodoFin = lide.classes.controls.textbox:new {
	Parent = formHistNomina.Toolbar,
	Name = 'txtPeriodoFin',
	Text = '',
	Width = 75,
}

local lblCedula = lide.classes.controls.label:new {
	Parent = formHistNomina.Toolbar, 
	Name = 'lblCedula', 
	Text = '   Documento:  ',
	Width = 75,	Height = 15,
}

local txtCedula = lide.classes.controls.textbox:new {
	Parent = formHistNomina.Toolbar,
	Name = 'txtCedula',
	Text = '',
	Width = 90
}

local tConcepChoices = {'Todos los conceptos'}
for row in SQLT.CONCEPTOS:listi 'recordid, CODIGO, DESCRIPCIO' do	
	tConcepChoices[#tConcepChoices +1] = string.format('%s - %s', row.CODIGO, row.DESCRIPCIO or '')
end

local cmbConcepto = lide.classes.controls.combobox:new {
	Parent = formHistNomina.Toolbar,
	Name = 'cmbConcepto',
	Width = 150,
	Choices = tConcepChoices,
	Flags = CB_READONLY + CB_DROPDOWN
}

cmbConcepto:setSelection(0)

local tAdmoraChoices = { 'Todas las Admoras' }

for row in SQLT.ADMORAS:listi 'recordid, CODIGO, DESCRIPCIO' do	
	tAdmoraChoices[#tAdmoraChoices +1] = string.format('%s - %s', row.CODIGO, row.DESCRIPCIO or '')
end

local cmbAdmora = lide.classes.controls.combobox:new {
	Parent = formHistNomina.Toolbar,
	Name = 'cmbAdmora',
	PosX = 50, PosY = 0,
	Width = 140,
	Choices = tAdmoraChoices
}

cmbAdmora:setSelection(0)

local btnProcesar = lide.classes.controls.button:new {
	Parent = formHistNomina.Toolbar,
	Name = 'btnProcesar',
	Text = 'Procesar',
}

if lide.platform.getOSName() == 'Windows' then
	formHistNomina:setWidth( btnProcesar:getPosX() + btnProcesar:getWidth() + 15) 
end

btnProcesar.onClick:setHandler ( function ( ... )

	local columns  = 'CODIGO, QUINCENA, CEDULA, DESCRIPCIO, DEV_DED, ADMORA, VALOR, DIAS'	
	local document = txtCedula:getText():gsub(' ', '')  --'1035232248'
	local fec_inic = txtPeriodoIni:getText()
	local fec_fina = txtPeriodoFin:getText()
	local concepto = cmbConcepto:getText():sub(1,3)
	local query    = 'select %s from TABLA_NOMHIST where QUINCENA >= \'%s\' and QUINCENA <= \'%s\' and VALOR > 0 '
	local queryend = ' order by QUINCENA, CEDULA, CODIGO, ADMORA'
	--local database = '/home/thedary/Proyectos/Nomina/testing.db'
	--local database = 'D:\\Nomina\\testing.db'
	local database = 'testing.db'

	local admora   = cmbAdmora:getText():sub(1,3)
	
	if cmbConcepto:getSelection() > 0 then
		query = query .. ' and CODIGO like \'' .. concepto ..'\''
	end

	if cmbAdmora:getSelection() > 0 then
		query = query .. ' and ADMORA like \'' .. admora ..'\''
	end

	if document ~= '' then
		query = query .. ' and CEDULA like \'' .. document ..'\''
	end
	
	query = query .. queryend

	printf('> query: %s', query:format(columns, fec_inic, fec_fina ))

	formHistNomina.Grid:getwxObj():ClearGrid()
	formHistNomina.GridTable:getwxObj():Clear()

	formHistNomina:setFromSQL (query:format(columns, fec_inic, fec_fina), database, 'sqlite3')
end)

formHistNomina.Toolbar:addTool(formHistNomina.EXCEL, '  Excel', APP_WORK_DIR .. '/imgs/report-excel.png')
formHistNomina.Toolbar:addSeparator()

formHistNomina.Toolbar:addControl( lblPeriodoIni ) 
formHistNomina.Toolbar:addControl( txtPeriodoIni ) 

formHistNomina.Toolbar:addControl( lblPeriodoFin ) 
formHistNomina.Toolbar:addControl( txtPeriodoFin ) 

formHistNomina.Toolbar:addControl( lblCedula )
formHistNomina.Toolbar:addControl( txtCedula )

formHistNomina.Toolbar:addSeparator()

formHistNomina.Toolbar:addControl( cmbConcepto ) 

formHistNomina.Toolbar:addSeparator()

formHistNomina.Toolbar:addControl( cmbAdmora ) 

formHistNomina.Toolbar:addSeparator()

formHistNomina.Toolbar:addControl( btnProcesar ) 

formHistNomina.onShow:setHandler( function ( event )
	if not app.PeriodoProceso then
		lide.core.error.lperr 'La tabla app.PeriodoProceso no existe, no es posible lanzar el formulario.'
	else	
		local Period = class 'Period'

		function Period:Period ( strPeriod )
			self.Year  = tonumber(strPeriod:sub(1, 4))
			self.Month = tonumber(strPeriod:sub(6, 7))
			self.PID   = tonumber(strPeriod:sub(#strPeriod, #strPeriod))
		end

		function Period:__tostring( lhs, rhs )
			local nMnth = self.Month
			local nYr   = self.Year
			if tonumber(nMnth) < 10 then nMnth = '0' .. nMnth end
			
			local period_id = self.PID
			
			return string.format('%d-%s-%d', nYr, nMnth, period_id)
		end

		local period_ini  = tostring(Period:new (app.PeriodoProceso.PERIODO))
		local period_id   = tonumber(period_ini:sub(#period_ini, #period_ini))

		if (period_id == 2) then
			local period_mnth = period_ini:sub(#period_ini-3, #period_ini-2)
			
			if tonumber(period_mnth) == 12 then
				period_mnth = '01'
			else
				period_mnth = period_mnth +1
			end

			if tonumber(period_mnth) < 10 then
				period_mnth = '0'.. period_mnth
			end
			period_fin  = period_ini:sub(1, 5) .. period_mnth ..'-'.. 1
		else
			period_fin = period_ini:sub(1, #period_ini-1) .. 2
		end
		
		local period_ini = tostring(Period:new '2016-06-1')
		
		txtPeriodoIni:setText(period_ini)
		txtPeriodoFin:setText(period_fin)
	end

	btnProcesar.onClick:call()
end)

app.AddResource(app.MODULES.LISTADO_MVNOMINA, function ( resID )
    formHistNomina:show(true)
end)

return formHistNomina