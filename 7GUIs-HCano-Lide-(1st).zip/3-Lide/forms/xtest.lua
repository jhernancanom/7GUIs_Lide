		local Period = class 'Period'
		
		function Period:Period ( strPeriod )
			self.Year = strPeriod:sub(1, 4)
		end
		
		function Period:__add( ... )
			return 0
		end

		local period_ini = Period:new '2016-06-1'
		local period_fin = Period + 1