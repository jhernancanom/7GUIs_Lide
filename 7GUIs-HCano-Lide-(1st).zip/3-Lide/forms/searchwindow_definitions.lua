--   AddRegistry ( table tdata )
--     Agrega una nueva fila

return  {
    Fields = { "Codigo", "Activo", "Documento", 
     "Nombre", "Apellidos", "Telefono", 
     "AFP", "EPS", "CCF", "CES", "Salario", 
     "Email", "Cargo", "FechaING", "FechaREI", "FechaRET" },

    AddRegistry = function ( self, tdata )
        if not tdata then error "tdata: No existe (nil)" end
        local grdClients = self.grdClients
        local grdTable   = self.grdClients.GridTable
        
        grdTable:AddRows(1)
        local number_rows = grdTable:GetNumberRows()
        grdTable:SetValue(number_rows -1, 0 , tdata.Codigo)
        grdTable:SetValue(number_rows -1, 1 , tdata.Activo)
        grdTable:SetValue(number_rows -1, 2 , tdata.Documento)
        grdTable:SetValue(number_rows -1, 3 , tdata.Nombre)
        grdTable:SetValue(number_rows -1, 4 , tdata.Apellidos)
        grdTable:SetValue(number_rows -1, 5 , tdata.Telefono)
        grdTable:SetValue(number_rows -1, 6 , tdata.AFP)
        grdTable:SetValue(number_rows -1, 7 , tdata.EPS)
        grdTable:SetValue(number_rows -1, 8 , tdata.CCF)
        grdTable:SetValue(number_rows -1, 9 , tdata.CES)
        grdTable:SetValue(number_rows -1, 10, tdata.Salario)
        grdTable:SetValue(number_rows -1, 11, tdata.Email)
        grdTable:SetValue(number_rows -1, 12, tdata.Cargo)
        grdTable:SetValue(number_rows -1, 13, tdata.FechaING)
        grdTable:SetValue(number_rows -1, 14, tdata.FechaREI)
        grdTable:SetValue(number_rows -1, 15, tdata.FechaRET)
    end,


}