--- lnomina/forms/windmain.lua
--- Ventana principal
--- 2016/03/30

-- Definimos las constantes:

enum {
    M_FILE_EMPLOY = lide.core.base.newid()

}

-- Importar clases necesarias
local Window     = lide.classes.widgets.window
local BoxSizer   = lide.classes.boxsizer
local HTMLView   = lide.classes.controls.htmlview

-- Importar funciones necesarias
local newid      = lide.core.base.newid
local messagebox = lide.core.base.messagebox

local thisWIN = Window:new { Name = 'windMain', Title = 'LNomina v0.0.1',
    
    Width = 800, Height = 600,

    Flags = WIN_DEFAULT_STYLE + WIN_MAXIMIZE_BOX,   
}



--thisWIN.VisorHTML = HTMLView : new {
--   Parent = thisWIN, Name = thisWIN:getName()..'.VisorHTML',
--   Flags  = HV_SCROLLBAR_AUTO, Filename = 'index.html'
--}

do 
   --- Valores utilizados por el constructor de menus:
    enum {
   		MENU_SEPARATOR = 1000,
   		MENU_DISABLED  = - ( lide.core.base.newid () ),
   	}

   function new ( what )
      if what:upper() == 'ID' then
         return lide.core.base.newid()
      end
   end

   t = dofile 'forms/mainwindow_menutemplate.lua' 
   new = nil
end

r = {}  for nMenu, oMenu in pairs(t) do r[nMenu] = Menu:new { Name = 'menu' .. oMenu.Title, Text = oMenu.Title,} --r = {}  for nMenu, oMenu in pairs(t) do r[nMenu] = Menu:new( oMenu.Title  )
   for nItem, oItem in pairs(oMenu) do
      if type(oItem) == 'table' and tonumber(oItem.ID) == MENU_DISABLED then
         local item = r[nMenu]:addItem( oItem.Text, MENU_DISABLED )
         item:get 'wxObj':Enable( false )
      elseif type(oItem) == 'table' then         
         r[nMenu]:addItem( oItem.Text, oItem.ID )
      elseif oItem == MENU_SEPARATOR then
         r[nMenu]:addSeparator()
      elseif type(oItem) == 'string' and tonumber(nItem) then
         local item = r[nMenu]:addItem( oItem )
         item:get 'wxObj':Enable( false )
      end
   end
end

thisWIN:setMenuBar (r)
thisWIN.Menubar = r

-- thisWIN:createStatusBar(2)
-- thisWIN:setStatusWidths( 120, 3000 )
-- thisWIN:setStatusText("Usuario: TMHFV013", 0)
-- thisWIN:setStatusBarPane( 1 )

thisWIN.onMenuSelected:setHandler ( function ( thisEvent, itemID, IsChecked )
   
   -- Verificamos si el usuario logueado actualmente tiene permiso para realizar la accion:
   if not App.loggedUser:HasAccessTo(itemID) then
      lide.core.base.messagebox ('No tienes acceso al recurso '.. itemID, 'Titulo', ICON_WARNING)
      return false
   end
   
   if ( itemID == app.M_MANAGE_PERMS ) then
      manPermsWindow.usersCombo:OnSelected(manPermsWindow.usersCombo:FindItem(loggedUser:GetUserName(), true ), loggedUser:GetUserName() )
      manPermsWindow.usersCombo:SetSelection( loggedUser:GetUserName() )
      manPermsWindow:showModal()
   end

   --- Si el recurso itemID existe en la tabla app.RESOURCES, ejecutarlo
   if app.RESOURCES[itemID] then
      app.RESOURCES[itemID] (itemID) 
   end
end)

thisWIN.onShow:setHandler( function  ( thisEVT, SHOWING )
    
    if SHOWING then
       printf('app.PeriodoProceso: %s', tostring(app.PeriodoProceso))
    end

   	--- Si NO existe un periodo abierto:
   	if not app.PeriodoProceso then
    	--- app.windMain.Menubar[3] --> En el orden del template "Procesos" es el tercer menu
      	app.windMain.Menubar[3]:setEnabled(app.MODULES.LIQUIDARFORM, false)
    end
   
   	--- Si NO existen registros en NOMMOV es porque ya la quincena está cerrada:
   	if ( SQLT.NOMMOV:getCount() == 0 ) then
    	  app.windMain.Menubar[5]:setEnabled(app.MODULES.REPETIR_NOM , false)
      	app.windMain.Menubar[3]:setEnabled(app.MODULES.PRC_PERIODO_CERRAR, false)
   	end

   	--- Si existen registros en NOMMOV es porque no se ha cerrado la quincena:
   	if ( SQLT.NOMMOV:getCount() > 0 ) then
    	--- app.windMain.Menubar[5] --> En el orden del template "Utilidades" es el tercer menu
      	app.windMain.Menubar[5]:setEnabled(app.MODULES.REPETIR_NOM , true)
      	app.windMain.Menubar[3]:setEnabled(app.MODULES.PRC_PERIODO_CERRAR, true)      
      	app.windMain.Menubar[3]:setEnabled(app.MODULES.LIQUIDARFORM, false)
   	end
   
end)

return thisWIN