local Progress = lide.classes.controls.progress
local Form     = lide.classes.widgets.form

local PProcess = app.modules.pprocess

local MessageBox = lide.core.base.messagebox

local infoStatus, lblHeaderInfo, gauProgress, btnLiquidar

local HTML_TEMPLATE = [[
PROCESO DE LIQUIDACIÓN &nbsp;&nbsp;&nbsp;&nbsp;[ %s ]
<p>
	%s
</p>
]]

local thisWIN = Form:new { Name = 'formLiquidarPeriodo',
	Title = 'Proceso de liquidación',
	Width = 500, Height = 250,
}

thisWIN:setMaxSize( thisWIN:getWidth(), thisWIN:getHeight() )
thisWIN:setMinSize( thisWIN:getWidth(), thisWIN:getHeight() )

-- Interceptamos OnClose para que la ventana no se destruyan por defecto cuando la cerramos.
--
thisWIN.onClose:setHandler(
	function ( this )
		thisWIN:setVisible(false)
	end
)

thisWIN.onShow:setHandler(function ( this, SHOWING )
	if SHOWING then
		--app.PeriodoAbierto = rawget( SQLT.PERIODOS:list('*', 'where ABIERTO == "S"'), 1) -- Abrimos el primer registro
		local sInfoText     = 'Se va a proceder a liquidar cada empleado activo en la base de datos, por favor asegurese de que está trabajando sobre el periodo correcto y haga clic en el botón "Liquidar".'
		thisWIN.infoStatus:setText( HTML_TEMPLATE:format(app.PeriodoProceso.PERIODO or '', sInfoText) )
		thisWIN.btnLiquidar:setText( 'Liquidar periodo' )		
		thisWIN.btnLiquidar:setEnabled(true)
	else
		if SQLT.NOMMOV:getCount() > 0 then
			app.windMain.Menubar[3]:setEnabled(app.MODULES.LIQUIDARFORM, false)
			app.windMain.Menubar[5]:setEnabled(app.MODULES.REPETIR_NOM       , true)
			app.windMain.Menubar[3]:setEnabled(app.MODULES.PRC_PERIODO_CERRAR, true)
		end
	end	
end)


btnLiquidar = Button:new { Parent = thisWIN, Name =  ( thisWIN:getName() .. '.btnLiquidar' ),
  Width = 113, Height = 27, PosX = (thisWIN:getWidth() - 113 -10), PosY = 8,
  Text = 'Liquidar periodo',
}

gauProgress = Progress:new { Parent = thisWIN, Name =  ( thisWIN:getName() .. '.gauProgress' ), 
	Height = 23, Width = thisWIN:getWidth() - 40 - btnLiquidar:getWidth(), PosX = 10, PosY = 10,
	Style = PROGRESS_SMOOTH,
	MaxValue = 100
}

infoStatus = HTMLReport:new { Parent = thisWIN, Name =  ( thisWIN:getName() .. '.infoStatus' ),
	Height = thisWIN:getHeight() - 50 - 10, Width = thisWIN:getWidth() - 20, PosX = 10, PosY = 50,
	Flags  = HV_SCROLLBAR_NEVER,
}

infoStatus:getwxObj() : SetFonts( 'Droid Sans Mono', 'Droid Sans Mono 10')

local backgroundProcess = PProcess :new ( function ( ... ) --> Creamos un nuevo proceso en paralelo
	local lide    = require 'lide.core.init'		
	
	require 'modules.init_databases'

	local Liquidados = dofile ("modules/liqnom.lua") ( ) if not Liquidados then return end

	local steps = {} for iEmpleado, empleado in pairs(Liquidados or {}) do

	-- Buscamos los conceptos dentro de la tabla de 'empleado'
	--
    for iConcepto, Concepto in pairs(empleado.CONCEPTOS) do		   	    	
    	local nPercConcept = ((((iEmpleado - 1) * #empleado.CONCEPTOS) + iConcepto) / (# empleado.CONCEPTOS * #Liquidados)) *100 
    	
    	send('GAU,'.. nPercConcept .. ','.. empleado.DOCUMENTO .. ','.. tostring(Concepto.DESCRIPCIO))

		SQLT.NOMMOV:insert( Concepto )
		end
	end
	

end, { }
)


backgroundProcess.onRunning:setHandler( function ( ... )
	local btn_saved_text = btnLiquidar:getText()
	local proc_msg = backgroundProcess:receive()
	
	local msg = [[
PROCESO DE LIQUIDACIÓN &nbsp;&nbsp;&nbsp;&nbsp;[ %s ]
<p>
	__linecontent__
</p>
]]
	
	if proc_msg then		
		local td = proc_msg:delim(',')
		local nPercent = tonumber(td[2])
		
		if nPercent then
			thisWIN :setTitle ('Proceso de liquidación ' .. nPercent .. '%')
			btnLiquidar:setText( 'Processing' )
		end

		if type(proc_msg) == 'string' and proc_msg:sub(1, 3):upper() == 'GAU' then 		
			local sInfoText = ('Procesando: CC: %d<br>%s'):format(tonumber(td[#td-1]), td[#td])

			gauProgress:setCurrentPos(tonumber(td[2]))
			infoStatus:setText( HTML_TEMPLATE:format(app.PeriodoProceso.PERIODO, sInfoText) )
		elseif type(proc_msg) == 'string' and proc_msg:delim()[1] == 'RESULT' then 		
			app.temp_int = tonumber(proc_msg:delim()[2])
		end
			
		infoStatus:getwxObj()  : Scroll ( 0,
			infoStatus:getwxObj()  : GetVirtualSize() . Height  - thisWIN:getHeight()
		)	infoStatus:getwxObj()  : Scroll ( 0,
		infoStatus:getwxObj()  : GetVirtualSize() . Height  - thisWIN:getHeight())
	
	end
end )

backgroundProcess.onEnded:setHandler( function ( ... )
	infoStatus:printLn( 'Proceso finalizado' )
	btnLiquidar:setText 'Correcto'
	
	if lide.platform:getOSName() == 'Unix' then
		thisWIN:getwxObj():EnableCloseButton(true)
	end
	
	gauProgress:setCurrentPos(0)

	--app.windMain.Menubar[3] --> En el orden del template "Procesos" es el tercer menu
	app.windMain.Menubar[3]:setEnabled(app.MODULES.LIQUIDARFORM, false)
	app.windMain.Menubar[3]:setEnabled(app.MODULES.PRC_PERIODO_CERRAR, true)
	app.windMain.Menubar[5]:setEnabled(app.MODULES.REPETIR_NOM, true)

	app.windMain:setEnabled(true)
	
	thisWIN :setTitle ('Completado')

	infoStatus:setText( HTML_TEMPLATE:format(app.PeriodoProceso.PERIODO, 
		('Liquidación exitosa.<p>Ahora puede generar sus reportes.') ) )
end )

btnLiquidar.onClick:setHandler( function ( ... )

	if SQLT.NOMMOV:getCount() > 0 then
		lide.core.base.messagebox ('No se ha cerrado la quincena anterior, debe cerrarla antes de liquidar.', 'Error', OK + ICON_EXCLAMATION )
		return false
	else		
		backgroundProcess:run()
		
		app.windMain:setEnabled(false)
		btnLiquidar:setEnabled(false)
		if lide.platform:getOSName() == 'Unix' then
			thisWIN:getwxObj():EnableCloseButton(false)
		end
	end
	
end )

thisWIN.infoStatus    = infoStatus
thisWIN.btnLiquidar   = btnLiquidar
thisWIN.lblHeaderInfo = lblHeaderInfo
thisWIN.gauProgress   = gauProgress

app.AddResource(app.MODULES.LIQUIDARFORM, function ( resID )
	app.PeriodoProceso = rawget( SQLT.PERIODOS:list('*', 'where ABIERTO == "S"'), 1) -- Abrimos el primer registro

    if not app.PeriodoProceso then
    	lide.core.base.messagebox 'No hay ningun periodo abierto'
    elseif SQLT.NOMMOV:getCount() > 0 then
    	lide.core.base.messagebox 'Actualmente hay una quincena liquidandose'
    else
    	thisWIN:show()
    end
end)

return thisWIN