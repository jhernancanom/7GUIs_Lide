---------------------------------------------------------------------------------------------------
---> thisWindow

local Form      = lide.classes.widgets.form
local Label     = lide.classes.controls.label
local Textbox   = lide.classes.controls.textbox
local Grid      = lide.classes.controls.grid
local ComboBox  = lide.classes.controls.combobox
local Toolbar   = lide.classes.controls.toolbar
local Numberbook = require 'XLSX.numberbook'

local isString  = lide.core.base.isstring

--luasql = require 'luasql.sqlite3'

local APP_WORK_DIR     = app.getWorkDir()

local ViewForm = class 'ViewForm' : subclassof 'Window' : global(false)

function ViewForm:ViewForm ( fields )

   public {
      Grid      = Grid,
      Toolbar   = Toolbar,
      --GridTable = GridTable

      RELOAD = 0,
      PRINT  = 1,
      EXCEL  = 2,
      PDF    = 3,
   }
   
   self.super : init ( fields )
   
   self:setMinSize(600, 300)

   private {
      ShowColumns = fields.ShowColumns or '*'
   }

   self.super.onClose : setHandler ( function ( evt )
       self:setVisible (false)
   end)

   self.Grid    = Grid:new    { Parent = self, Name = ( self:getName() .. '.Grid' ), SelectMode = GRID_SELMODE_ROWS }
   self.Toolbar = Toolbar:new { Parent = self, Name = self:getName() .. '.Toolbar', Flags  = TB_FLAT +TB_NODIVIDER + TB_HORIZONTAL + TB_HORZ_LAYOUT + TB_TEXT, WindowManaged = true }   

   -- self.GridTable = lide.classes.gridtable : new ( 'select '..fields.ShowColumns..' from '.. fields.SQLTable, 'testing.db', "sqlite3" )
   -- dice que ShowColumns no existe.....
   self.GridTable = lide.classes.gridtable : new ( 'select * from '.. fields.SQLTable, 'testing.db', "sqlite3" )
   
   self.Grid:setTable(self.GridTable, false, false)
   self.Grid:autoSizeColumns( false )

   self.Grid:setDefaultCellAlignment(ALIGN_CENTRE, ALIGN_CENTRE)
   self.Grid:setDefaultCellAlignment(ALIGN_CENTRE, ALIGN_CENTRE)
   self.Grid:setDefaultCellFont("Courier New", 8)
   self.Grid:setRowLabelSize(23)
   self.Grid:setColLabelSize(23)
   self.Grid:getwxObj():EnableDragColSize(true)
  
   self.Toolbar:setImageSizes(18, 18) --> Establecemos el tamano de las imagenes de los items.
   
   if fields.DefaultTools ~= false then
      if type(fields.DefaultTools) == 'table' then
         for _, sDefToolName in ipairs(fields.DefaultTools) do
            printf('%s', sDefToolName)
         end         
      else
         self.Toolbar:addTool(self.RELOAD, '  Recargar', APP_WORK_DIR .. '/imgs/arrow-circle-315.png')
         self.Toolbar:addSeparator()
         self.Toolbar:addTool(self.PRINT, '  Imprimir', APP_WORK_DIR .. '/imgs/printer.png')
         self.Toolbar:addTool(self.EXCEL, '  Excel'   , APP_WORK_DIR .. '/imgs/report-excel.png')   
         self.Toolbar:addTool(self.PDF  , '  PDF'     , APP_WORK_DIR .. '/imgs/document-pdf.png')
         
         self.Toolbar:setToolEnabled(self.PRINT, false)
         self.Toolbar:setToolEnabled(self.PDF  , false)         
      end
   end

   self.Toolbar.onToolClick:setHandler(function ( this, nID )

      if (nID == self.EXCEL) then   
         local function generate_xlsx( strFilename )
            local Reporte     = Numberbook:new    { Name = 'Reporte', Filename = strFilename }
            local Arial10     = Reporte:newFormat { FontName = 'Arial', FontSize = 10, Bold   = false }
            local Arial10Bold = Reporte:newFormat { FontName = 'Arial', FontSize = 10, Bold   = true }
            local Listado     = Reporte:addSheet  'Listado'

            for nC = 0, self.GridTable:getNumberCols() -1 do
               local col_name = self.GridTable:getColLabelValue(nC)        
               
               Listado:getCobj():write( 0, nC, col_name, Arial10Bold )
               
               for nR = 0, self.GridTable:getNumberRows() -1 do
                  local val_str  = self.GridTable:getValue(nR, nC)
                  Listado:getCobj():write( nR+1, nC,  val_str , Arial10 )
               end
            end
            
            Reporte:close()
         end

         pcall(generate_xlsx, './ViewForm.xlsx')

         io.popen '"C:\\Program Files\\Microsoft Office\\Office14\\excel.exe" .\\ViewForm.xlsx'     
      end
   end)

   io.stdout:write(('[%s]: %s'):format( self.super:class():name(), self:getName()..'\n'))
end

function ViewForm:getShowColumns( )
   return self.ShowColumns
end

function ViewForm:setShowColumns( strCols )
   isString(strCols)
   self.ShowColumns = strCols
end

function ViewForm:setFromSQL( strQuery, strDatabase, strDriver )
   self.Grid:getwxObj():ClearGrid()
   self.GridTable:getwxObj():Clear()
   
   local backgroundProcess = require 'modules.pprocess' : new ( function ( EVT ) 
      local env, conn, cur, row, col_names, row_name, num_cols, num_rows, grid_table, row_number   
      local luasql = require 'luasql.sqlite3'        --> It's the same.
      
      env = luasql.sqlite3()
            
      conn = env:connect(strDatabase)
      
      cur = conn:execute(strQuery)

      col_names  = cur:getcolnames()   --> table of strings, contains columns of query result
      num_cols = #col_names            --> get number of columns
      num_rows = 1                     --> initialize rows

      -- set columns labels:
      for col = 1, #col_names do
         local row_name = col_names[col]
      end

      send(col_names, 'col_names')

      -- add rows to GridTable object:
      row = cur:fetch ({}, "a")
      
      local q_res = {}

      while row do
         row_number = (row_number or 0) +1        

         q_res[#q_res+1] = {}
         for col_number = 1, #col_names do
            row_name = col_names[col_number]
            q_res[#q_res][col_number] = tostring(row[row_name])
         end
         
         row = cur:fetch (row, "a")
      end
      send(q_res, 'rowsinfo')
   end )

   --local self.Grid = self.Grid

   backgroundProcess.onRunning:setHandler ( function ( EVT ) 
      EVT.col_names = backgroundProcess:receive 'col_names' or EVT.col_names
      EVT.rowsinfo  = backgroundProcess:receive 'rowsinfo' or EVT.rowsinfo

   if EVT.col_names and EVT.rowsinfo then
      local col_names = EVT.col_names
      local rowsinfo  = EVT.rowsinfo

      self.GridTable = lide.classes.gridtable:new(# EVT.rowsinfo, #EVT.col_names)

      if col_names then         
         for k,v in pairs(col_names) do
            self.GridTable:setColLabelValue(k-1, v)            
         end
      end     

      if rowsinfo then
         local faltantes = #rowsinfo - self.GridTable:getNumberRows()
         self.GridTable:addRows(faltantes)

         for rn, rinf in pairs(rowsinfo) do -- rn = record number, rinf = row info            
            for col_number, cell_text in pairs(rinf) do
               self.GridTable:setValue(rn-1, col_number-1, tostring(cell_text))
            end
         end

      end
      
   end
      --self.Grid:getwxObj():ForceRefresh()
   end)

   backgroundProcess.onEnded:setHandler(function ( EVT )
      self.Grid:setTable(self.GridTable)
      self.Grid:getwxObj():ForceRefresh()

      if # backgroundProcess:receive 'rowsinfo' == 0 then
         self.Grid:setVisible(false)
      else
         self.Grid:setVisible(true)
      end

   end)
   
   backgroundProcess:run()

end

return ViewForm

-- thisWin = ViewForm:new {
--    Name = 'vform', Title = 'vForm',
-- 
--    Width = 600, Height = 300,
-- 
--    ShowColumns = 'CODIGO, ACTIVO, DOCUMENTO, NOMBRE, APELLIDOS, CARGO, AFP, EPS, SALARIO, EMAIL',
--    Database = 'testing.db',
--    SQLTable = 'TABLA_NOMMAE',
-- }
-- 
-- 
-- thisWin:show()
