local defs = {
   Inputs = { "txtCodigo", "cmbClase", "txtConcepto", "txtContable" }
}

-- PARA NO REDEFINIR
-- enum {
-- 	FORM_EDIT = false,
-- 	FORM_VIEW = true,
-- }



function defs:ClearInputs( ... )
	for _, nameobj in pairs(self.Inputs) do
		self[nameobj]:SetText('')
   end
end

function defs:SetViewMode( ViewMode )
   -- Definimos los controles con los que vamos a trabajar:
   local tObjects = defs.Inputs
      -- Recorremos la tabla y establecemos la propiedad Enabled dependiendo del caso:
      for _, nameobj in pairs(tObjects) do
          if ViewMode == FORM_VIEW then
            self[nameobj]:SetEnabled(false)
          else
            self[nameobj]:SetEnabled(true)
          end
      end

   -- Set Toolbar buttons:
   if ViewMode == FORM_EDIT then
      self.Toolbar:SetToolEnabled(ID_DELETE_REG, true)

      self.btnCancel:SetVisible(true)
      self.btnSave:SetVisible(true)
   else
      self.Toolbar:SetToolEnabled(ID_EDIT_REG  , true)
      self.Toolbar:SetToolEnabled(ID_DELETE_REG, false)    
      self.btnCancel:SetVisible(false)
      self.btnSave  :SetVisible(false)
   end
   
   self.ViewMode = ViewMode -- Guardar valor
   
   self.txtCodigo:SetEnabled(false) --> RECARGANDO
end

function defs:LoadRegistry( tDatos ) -- Cargar_datos 
   if not tDatos then error ("La tabla no es correcta",2 ) end
	self.txtCodigo  :SetText (tostring(tDatos.CODIGO    ))
   self.txtConcepto:SetText (tostring(tDatos.DESCRIPCIO ))
   self.txtContable:SetText (tostring(tDatos.CONTABLE   ))

   if     tDatos.DEV_DED == 'N' then
      self.cmbClase:SetSelection(0)
   elseif tDatos.DEV_DED == '+' then
      self.cmbClase:SetSelection(1)
   elseif tDatos.DEV_DED == '-' then
      self.cmbClase:SetSelection(2)
   end

   self.CURRENT_RECORD = tDatos
end

function defs:ToTable( )
	return {
		CODIGO     = self.txtCodigo:GetText(),	
      DESCRIPCIO = self.txtConcepto:GetText(),
      CONTABLE   = self.txtContable:GetText(),
      DEV_DED    = self.cmbClase:GetSelection(),
   }
end

function defs:DisableToolbar( ... )
   if (...) then 
      for _, id in pairs { ... } do
         self.Toolbar:SetToolEnabled(id, false) 
      end
   end
end

function defs:EnableToolbar( ... )
   if (...) then 
      for _, id in pairs { ... } do
         self.Toolbar:SetToolEnabled(id, true)
      end
   end
end

return defs