local defs = {}

enum {
	FORM_EDIT = false,
	FORM_VIEW = true,
}

function defs:ClearInputs( ... )
	local tObjects = {"txtCodigo", "txtNombre", "txtApellidos", "txtCargo", "txtDocumento", "txtFecha", "txtSalario", "txtEmail", "txtTelefono", "txtEPS", "txtAFP"}
	for _, nameobj in pairs(tObjects) do
		self[nameobj]:SetText('')
   	end
end

function defs:SetViewMode( ViewMode )
-- Definimos los controles con los que vamos a trabajar:
local tObjects = {"txtCodigo", "cmbActivo", "txtNombre", "txtApellidos", "txtCargo", "txtDocumento", "txtFecha", "txtSalario", "txtEmail", "txtTelefono", "txtEPS", "txtAFP"}
      -- Recorremos la tabla y establecemos la propiedad Enabled dependiendo del caso:
      for _, nameobj in pairs(tObjects) do
          if ViewMode == FORM_VIEW then
            self[nameobj]:SetEnabled(false)
          else
            self[nameobj]:SetEnabled(true)
          end
      end

   -- Set Toolbar buttons:
   if ViewMode == FORM_EDIT then
      self.Toolbar:SetToolEnabled(ID_DELETE_EMP, true)
      --self.Toolbar:SetToolEnabled(ID_RELOAD_EMP, true)

      self.btnCancel:SetVisible(true)
      self.btnSave:SetVisible(true)
   else
      self.Toolbar:SetToolEnabled(ID_DELETE_EMP, false)
      --self.Toolbar:SetToolEnabled(ID_RELOAD_EMP, false)
      
      self.Toolbar:SetToolEnabled(ID_EDIT_EMP, true)

      self.btnCancel:SetVisible(false)
      self.btnSave:SetVisible(false)
   end

   --for _, idtool in pairs { ID_EDIT_EMP, ID_FIRST_EMP, ID_BEFORE_EMP, ID_NEXT_EMP, ID_LAST_EMP, ID_SEARCH_EMP } do
      --self.Toolbar:SetToolEnabled(idtool, ViewMode)
   --end
   
   self.ViewMode = ViewMode -- Guardar valor
   
   self.txtCodigo:SetEnabled(false) --> RECARGANDO
end

function defs:LoadTable( tDatos ) -- Cargar_datos
	assert(tonumber(tDatos.ACTIVO), "ACTIVO DEBE SER 1 O 0")   
	self.cmbActivo:SetSelection(tonumber(tDatos.ACTIVO))
   
	self.txtCodigo:SetText   (tostring(tDatos.CODIGO))
	self.txtNombre:SetText   (tostring(tDatos.NOMBRE))
	self.txtApellidos:SetText(tostring(tDatos.APELLIDOS))
	self.txtCargo:SetText    (tostring(tDatos.CARGO))
	self.txtDocumento:SetText(tostring(tDatos.DOCUMENTO))
	self.txtFecha:SetText    (tostring(tDatos.F_INGRESO))
	self.txtSalario:SetText  (tostring(tDatos.SALARIO))
	self.txtEmail:SetText    (tostring(tDatos.EMAIL))
	self.txtTelefono:SetText (tostring(tDatos.TELEFONO))
	self.txtEPS:SetText      (tostring(tDatos.EPS))
	self.txtAFP:SetText      (tostring(tDatos.AFP))
end

function defs:ToTable( )
	return {
		CODIGO    = self.txtCodigo:GetText(),
		ACTIVO    = self.cmbActivo:GetSelection() or 0, -->> 0 es true, 1 es false
		NOMBRE    = self.txtNombre:GetText(),   
		APELLIDOS = self.txtApellidos:GetText(),
		CARGO     = self.txtCargo:GetText(),    
		DOCUMENTO = self.txtDocumento:GetText(),
		F_INGRESO = self.txtFecha:GetText(),    
		SALARIO   = self.txtSalario:GetText(),  
		EMAIL     = self.txtEmail:GetText(),    
		TELEFONO  = self.txtTelefono:GetText(), 
		EPS       = self.txtEPS:GetText(),      
		AFP       = self.txtAFP:GetText(),
   }
end

function defs:LoadEmployee( nextRD )
   if not nextRD then error ("La tabla no es correcta",2 ) end
      self.CURRENT_EMPLOY = nextRD
      self:LoadTable { 
         CODIGO  = nextRD.Codigo , ACTIVO = nextRD.Activo, -- 0 es true 1 es false
         NOMBRE  = nextRD.Nombre , APELLIDOS = nextRD.Apellidos,
         CARGO   = nextRD.Cargo  , DOCUMENTO = nextRD.Documento,
         SALARIO = nextRD.Salario, F_INGRESO = nextRD.FechaING,  -- F_INGRESO = Date "29/07/2014", 
         EMAIL   = nextRD.Email  , TELEFONO  = nextRD.Telefono, 
         EPS     = nextRD.EPS    , AFP = nextRD.AFP
      }
end   

return defs