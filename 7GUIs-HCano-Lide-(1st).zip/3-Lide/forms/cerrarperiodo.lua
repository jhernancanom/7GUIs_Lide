--- lnomina/forms/windmain.lua
--- Ventana principal
--- 2016/03/29

app.AddResource(app.MODULES.PRC_PERIODO_CERRAR, function ( resID )
	--- Comprobamos el numero de registros en la tabla NOMMOV
	--- si es igual a cero significa que la tabla esta, vacia y la quincena ya fue cerrada
	---
	if ( SQLT.NOMMOV:getCount() == 0 ) then
		lide.core.base.messagebox ('La quincena anterior ya está cerrada.', 'Información', ICON_INFORMATION)
		-- return false, 'La quincena anterior ya está cerrada.'
	elseif not app.PeriodoProceso then
		lide.core.base.messagebox ('No hay algún periodo abierto.', 'Información', ICON_INFORMATION)
	else
		app.formCerrarPeriodo:show()
	end
end)

local Label    = lide.classes.controls.label
local Progress = lide.classes.controls.progress
local Form     = lide.classes.widgets.form
local PProcess = app.modules.pprocess

local MessageBox = lide.core.base.messagebox

local infoStatus, lblHeaderInfo, gauProgress, btnCerrarPeriodo

local thisWIN = Form:new { Name = 'formCerrarPeriodo',
	Title = 'Proceso de cierre',
	Width = 500, Height = 250,
}

thisWIN:setMaxSize( thisWIN:getWidth(), thisWIN:getHeight() )
thisWIN:setMinSize( thisWIN:getWidth(), thisWIN:getHeight() )

-- Interceptamos OnClose para que la ventana no se destruyan por defecto cuando la cerramos.
--
thisWIN.onClose:setHandler(function ( this )
 	thisWIN:setVisible(false)

 	app.windMain.Menubar[3]:setEnabled(App.MODULES.LIQUIDARFORM, false)
 	app.windMain.Menubar[5]:setEnabled(App.MODULES.REPETIR_NOM , false)
end)

thisWIN.onShow:setHandler(function ( this, SHOWING )
   	if SHOWING then
   		local sInfoText = 'Se va a cerrar el periodo liquidado.<p><p>Si está seguro de que desea realizar este procedimiento, haga clic en el botón "Cerrar periodo"'
   		thisWIN.infoStatus:setText( HTML_TEMPLATE:format(app.PeriodoProceso.PERIODO or '', sInfoText) )
   	end
end)

local btnCerrarPeriodo = Button:new { Parent = thisWIN, Name =  ( thisWIN:getName() .. '.btnCerrarPeriodo' ),
  Width = 113, Height = 27, PosX = (thisWIN:getWidth() - 113 -10), PosY = 8,
  Text = 'Cerrar periodo',
}

local gauProgress = Progress:new { Parent = thisWIN, Name =  ( thisWIN:getName() .. '.gauProgress' ), 
	Height = 23, Width = thisWIN:getWidth() - 40 - btnCerrarPeriodo:getWidth(), PosX = 10, PosY = 10,
	Style = PROGRESS_SMOOTH,
	MaxValue = 100
}


local infoStatus = HTMLReport:new { Parent = thisWIN, Name =  ( thisWIN:getName() .. '.infoStatus' ),
	Height = thisWIN:getHeight() - 50 - 10, Width = thisWIN:getWidth() - 20, PosX = 10, PosY = 50,
	Flags  = HV_SCROLLBAR_NEVER,
}

infoStatus:getwxObj() : SetFonts( 'Droid Sans Mono', 'Droid Sans Mono 10')

local backgroundProcess = PProcess :new ( function ( ... ) --> Creamos un nuevo proceso en paralelo
	local lide = require 'lide.core.init' --> Cargamos lide dentro del parallel process
	
	require 'modules.init_databases'

	local tRegistros = SQLT.NOMMOV:list( '*' )
	
	for nRow, row in pairs(tRegistros) do
		local nPercRegistro = tostring((nRow / #tRegistros) * 100)

		--- ocultamos recordid para que no hayan problemas logicos en la base de datos
		--- cuando intentemos sobreescribir un primarykey

		local nRecordID = row.recordid
		row.recordid    = nil
		SQLT.NOMHIST:insert ( row )
		SQLT.NOMMOV:delete ( nRecordID )
		
		send('GAU,'.. nPercRegistro .. ','.. nRow ) --> Send two values
	end
end, { }
)


backgroundProcess.onRunning:setHandler( function ( ... )
	local btn_saved_text = btnCerrarPeriodo:getText()
	local proc_msg = backgroundProcess:receive()
	
	local msg = [[
PROCESO DE LIQUIDACIÓN &nbsp;&nbsp;&nbsp;&nbsp;[ %s ]
<p>
	__linecontent__
</p>
]]
	
	if proc_msg then		
		local td = proc_msg:delim(',')
		local nPercent = tonumber(td[2])
		
		if nPercent then
			thisWIN :setTitle ('Proceso de cierre ' .. nPercent .. '%')
			btnCerrarPeriodo:setText( 'Procesando' )
		end

		if type(proc_msg) == 'string' and proc_msg:sub(1, 3):upper() == 'GAU' then 		
			app.temp_int = td[#td]
			local sInfoText = ('Respaldando en el histórico: %d <br>%s'):format(tonumber(td[#td]), '')

			gauProgress:setCurrentPos(tonumber(td[2]))
			
			infoStatus:setText( HTML_TEMPLATE:format( (app.PeriodoProceso).PERIODO, sInfoText) )
		end
			
		infoStatus:getwxObj()  : Scroll ( 0,
			infoStatus:getwxObj()  : GetVirtualSize() . Height  - thisWIN:getHeight()
		)	infoStatus:getwxObj()  : Scroll ( 0,
		infoStatus:getwxObj()  : GetVirtualSize() . Height  - thisWIN:getHeight())
	end
end )

backgroundProcess.onEnded:setHandler( function ( ... )
	--- Cerrar periodo en la tabla pèriodos:
	SQLT.PERIODOS:update ( app.PeriodoProceso.recordid, {  ABIERTO = 'N'  } )

	infoStatus:printLn( 'Proceso finalizado' )
	btnCerrarPeriodo:setText 'Correcto'
	thisWIN:getwxObj():EnableCloseButton(true)
	--thisWIN:show(false)
	gauProgress:setCurrentPos(0)

	---App.windMain.Menubar[3] --> En el orden del template "Procesos" es el tercer menu
	App.windMain.Menubar[3]:setEnabled(App.MODULES.PRC_PERIODO_CERRAR, false)


	App.windMain:setEnabled(true)
	thisWIN :setTitle ('Completado')

	infoStatus:setText( HTML_TEMPLATE:format(app.PeriodoProceso.PERIODO, 
		'Periodo cerrado exitosamente.<p>Registros enviados al histórico: %d'):format ( app.temp_int )
	)

	app.PeriodoAbierto = nil
end )

btnCerrarPeriodo.onClick:setHandler( function ( ... )
	---	Si la quincena no esta cerrada entonces procederemos a lanzar un mensaje de confirmacion:
	if lide.core.base.messagebox ('Se va a proceder a cerrar la quincena liquidada.\n\n¿Está seguro de que desea realizar este procedimiento?', 
   		'Advertencia', ICON_EXCLAMATION + YES_NO + NO_DEFAULT) == YES then
		
		backgroundProcess:run()

		--App.windMain.Menubar[3] --> En el orden del template "Procesos" es el tercer menu
		App.windMain.Menubar[3]:setEnabled(App.MODULES.PRC_PERIODO_CERRAR, true)

		
		App.windMain:setEnabled(false)
		btnCerrarPeriodo:setEnabled(false)
		thisWIN:getwxObj():EnableCloseButton(false)
	end
	
end )

thisWIN.infoStatus    = infoStatus
thisWIN.btnCerrarPeriodo  = btnCerrarPeriodo
thisWIN.lblHeaderInfo = lblHeaderInfo
thisWIN.gauProgress   = gauProgress


--thisWIN:show(true)

return thisWIN