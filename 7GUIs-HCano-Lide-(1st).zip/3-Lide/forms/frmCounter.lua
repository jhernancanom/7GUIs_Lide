-- frmCounter.lua

--  
-- Contador en lide 
--  

local Form    = lide.classes.widgets.form
local Textbox = lide.classes.controls.textbox

local thisWIN = Form:new { 
   Name = 'frmCounter',
   Flags  = WIN_DEFAULT_STYLE + WIN_TOOL_WINDOW + WIN_STAY_ON_TOP,
   Title  = 'Acceder a la aplicaci�n'
}

thisWIN.btnContar = Button:new {
   Name = 'frmCounter.btnContar', Parent = thisWIN,
   PosX = 150, PosY = 20,-- Width = 92, Height = 24,
   Text = 'Contar',
}

if lide.platform.getOSName()  == 'Windows' then
   thisWIN:setWidth(300) thisWIN:setHeight(145)
elseif lide.platform.getOSName() == 'Unix' then
   thisWIN:setWidth(290) thisWIN:setHeight(115)
end

thisWIN:setMaxSize( thisWIN:getWidth(), thisWIN:getHeight() )
thisWIN:setMinSize( thisWIN:getWidth(), thisWIN:getHeight() )

thisWIN.onClose:setHandler( function ( this )
   os.exit()
end)

thisWIN.txtContar = Textbox:new { 
   Name = 'frmCounter.txtContar', Parent = thisWIN,
   PosX = 40, PosY = 20, Width = 70, Height = 25,  
   Text = '0'
}

thisWIN.btnContar.onClick:setHandler ( function ( ... ) 
        -- aqu� se escribe lo que el prog debe hacer
		-- al dar click en el bot�n
   local nNum = 0 
      nNum = tonumber(thisWIN.txtContar:getText())
      thisWIN.txtContar:setText(tostring(nNum+1))
		
end)

return thisWIN

--