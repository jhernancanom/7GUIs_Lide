this = Window:new {}


this.lvConceptos = PropertyGrid:new{ 
  Parent = this,
  Flags  = wx.wxLC_REPORT + wx.wxLC_LIST
}

this.lvConceptos:AddItem ('Salario basico')
this.lvConceptos:AddItem ('Aux. Transporte')


this:show()


return this