--- lnomina/forms/repetirnomina.lua
--- Formulario Repetir Nomina
--- 2016/03/29

local infoStatus, lblHeaderInfo, gauProgress, btnRepetirLiq

--- import framework required classes:

local Form       = lide.classes.widgets.form
local Progress   = lide.classes.controls.progress
local MessageBox = lide.core.base.messagebox

--- import app modules:

local PProcess   = app.modules.pprocess

--- add this resource to the app:

app.AddResource(app.MODULES.REPETIR_NOM, function ( resID )
	app.formRepetirNomina:show()
end)

--- Create the form:
---
local thisWIN = Form:new { 	
	Name  = 'formRepetirNomina',
	Title = 'Repetir liquidación',
	Width = 500, Height = 250,
}

thisWIN:setMaxSize( thisWIN:getWidth(), thisWIN:getHeight() )
thisWIN:setMinSize( thisWIN:getWidth(), thisWIN:getHeight() )

--- Interceptamos onClose para que la ventana no se destruyan por defecto cuando la cerramos.
---
thisWIN.onClose:setHandler(function ( this )
 	
 	-- Si no hay registros en NOMMOV es porque no hay nada liquidado:
 	if ( SQLT.NOMMOV:getCount() == 0 ) then
 		app.windMain.Menubar[3]:setEnabled(app.MODULES.LIQUIDARFORM, true)
 		app.windMain.Menubar[5]:setEnabled(app.MODULES.REPETIR_NOM , false)
 		app.windMain.Menubar[3]:setEnabled(app.MODULES.PRC_PERIODO_CERRAR, false)
 	end
 	thisWIN:setVisible(false)
end)

thisWIN.onShow:setHandler(function ( this, SHOWING )
   	if SHOWING then
   		--app.PeriodoAbierto = rawget( SQLT.PERIODOS:list('*', 'where ABIERTO == "S"'), 1) 
		thisWIN.btnRepetirLiq:setText('Repetir')
   		thisWIN.btnRepetirLiq:setEnabled(true)
   	end
end)

local btnRepetirLiq = Button:new { Parent = thisWIN, Name =  ( thisWIN:getName() .. '.btnRepetirLiq' ),
  Width = 113, Height = 27, PosX = (thisWIN:getWidth() - 113 -10), PosY = 8,
  Text = 'Repetir',
}

local gauProgress = Progress:new { Parent = thisWIN, Name =  ( thisWIN:getName() .. '.gauProgress' ), 
	Height = 23, Width = thisWIN:getWidth() - 40 - btnRepetirLiq:getWidth(), PosX = 10, PosY = 10,
	Style = PROGRESS_SMOOTH,
	MaxValue = 100
}

local infoStatus = HTMLReport:new { Parent = thisWIN, Name =  ( thisWIN:getName() .. '.infoStatus' ),
	Height = thisWIN:getHeight() - 50 - 10, Width = thisWIN:getWidth() - 20, PosX = 10, PosY = 50,
	Flags  = HV_SCROLLBAR_NEVER,
}

infoStatus:getwxObj() : SetFonts( 'Droid Sans Mono', 'Droid Sans Mono 10')

local backgroundProcess = PProcess :new ( function ( ... ) --> Creamos un nuevo proceso en paralelo
	local lide = require 'lide.core.init' --> Cargamos lide dentro del parallel process
	
	require 'modules.init_databases'

	local tRegistros = SQLT.NOMMOV:list( '*' )
	for nRow, row in pairs(tRegistros) do

		SQLT.NOMMOV:delete ( row.recordid )

		local nPercRegistro = tostring((nRow / #tRegistros) * 100)
		send('GAU,'.. nPercRegistro .. ','.. nRow ) --> Send two values
	end
end, { }
)

backgroundProcess.onRunning:setHandler( function ( ... )
	local btn_saved_text = btnRepetirLiq:getText()
	local proc_msg = backgroundProcess:receive()
	
	local msg = [[
REVIRTIENDO REGISTROS &nbsp;&nbsp;&nbsp;&nbsp;[ %s ]
<p>
	__linecontent__
</p>
]]
	
	if proc_msg then		
		local td = proc_msg:delim(',')
		local nPercent = tonumber(td[2])
		
		if nPercent then
			thisWIN :setTitle ('Repitiendo nómina ' .. nPercent .. '%')
			btnRepetirLiq:setText( 'Procesando' )
		end

		if type(proc_msg) == 'string' and proc_msg:sub(1, 3):upper() == 'GAU' then 		
			app.temp_int = td[#td]
			local sInfoText = ('Registros actualizados: %d <br>%s'):format(tonumber(td[#td]), '')

			gauProgress:setCurrentPos(tonumber(td[2]))
			
			infoStatus:setText( HTML_TEMPLATE:format( '---', sInfoText) )
		end
			
		infoStatus:getwxObj()  : Scroll ( 0,
			infoStatus:getwxObj()  : GetVirtualSize() . Height  - thisWIN:getHeight()
		)	infoStatus:getwxObj()  : Scroll ( 0,
		infoStatus:getwxObj()  : GetVirtualSize() . Height  - thisWIN:getHeight())
	end
end )

backgroundProcess.onEnded:setHandler( function ( ... )

	infoStatus:printLn( 'Proceso finalizado' )
	btnRepetirLiq:setText 'Correcto'
	thisWIN:getwxObj():EnableCloseButton(true)
	gauProgress:setCurrentPos(0)

	-----app.windMain.Menubar[3] --> En el orden del template "Procesos" es el tercer menu
	app.windMain.Menubar[3]:setEnabled(app.MODULES.LIQUIDARFORM, false)


	app.windMain:setEnabled(true)
	thisWIN :setTitle ('Completado')

	infoStatus:setText( HTML_TEMPLATE:format(app.PeriodoProceso.PERIODO, 
		'Liquidación revertida exitosamente.<p>Registros actualizados: %d'):format ( app.temp_int )
	)

	app.PeriodoProceso = nil
end )

btnRepetirLiq.onClick:setHandler( function ( ... )
	---
	---	Si la quincena no esta cerrada entonces procederemos a lanzar un mensaje de confirmacion:
	---
	if lide.core.base.messagebox ('Se va a revertir la liquidación de éste periodo.\n\n¿Está seguro de que desea realizar este procedimiento?', 
   		'Advertencia', ICON_EXCLAMATION + YES_NO + NO_DEFAULT) == YES then
		
		backgroundProcess:run()

		--app.windMain.Menubar[3] --> En el orden del template "Procesos" es el tercer menu
		app.windMain.Menubar[3]:setEnabled(app.MODULES.PRC_PERIODO_CERRAR, true)
		
		app.windMain:setEnabled(false)
		btnRepetirLiq:setEnabled(false)
		thisWIN:getwxObj():EnableCloseButton(false)
	end
	
end )

thisWIN.infoStatus    = infoStatus
thisWIN.btnRepetirLiq = btnRepetirLiq
thisWIN.lblHeaderInfo = lblHeaderInfo
thisWIN.gauProgress   = gauProgress


--thisWIN:show(true)

return thisWIN