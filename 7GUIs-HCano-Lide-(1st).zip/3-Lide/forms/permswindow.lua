-------------------------------------------------------------------------
-------------------------------------------------------------------------


-------------------------------------------------------------------------
-------------------------------------------------------------------------

local usersLabel, usersCombo, info1Label, permList, permCancel, permSave

local tW = Window:new { Name = 'managusers_window', -- thisWindow
    Width = 188, Height = 380,
    Title  = "Administrar permisos", -- Style = WIN_CAPTION,
}

tW.onShow:setHandler( function ( bShowed )
    local txtUser = App.loggedUser:GetUserName()
    local nselItm = usersCombo:FindItem(txtUser)
    usersCombo:SetSelection(nselItm)
    usersCombo:OnSelected(nselItm, txtUser)
end, tW)


usersLabel = Label { Name =  ( tW.Name .. '.usersLabel' ), Parent = tW,
  PosX = 11, PosY = 13, Flags  = CB_READONLY,
  Text = "Usuario:",
}

usersCombo = ComboBox { Name =  ( tW.Name .. '.usersCombo' ), Parent = tW,
  PosX = 60, PosY = 9, Flags  = CB_READONLY,
}

local Users = {} for i,v in pairs (App.USERS) do Users[i] = i end
usersCombo:SetChoices (Users)

info1Label = Label { Name =  ( tW.Name .. '.info1Label' ), Parent = tW, 
  PosX = 11, PosY = 39,
  Text = "Escoger permisos:",
}

permList = CheckListBox { Name =  ( tW.Name .. '.permList' ), Parent = tW,
  PosX = 11, PosY = 60, Width = 161, Height = 250
}

permList.Choices = {} for module_str in pairs(App.MODULES) do
    permList.Choices[#permList.Choices+1] = tostring(module_str)
end

permList:SetChoices ( permList.Choices )

permCancel = Button:new { Name =  ( tW.Name .. '.permCancel' ), Parent = tW,
   PosX = 11, PosY = 313, Width = 77, Height = 26,
   Text = "Cancelar"
}

permSave = Button:new { Name =  ( tW.Name .. '.permSave' ), Parent = tW,
   PosX = 96, PosY = 313, Width = 77, Height = 26,
   Text = "Actualizar"
}

function usersCombo:OnSelected ( nSel, sSelText )  
   ------------------------------------
   -- func methd = uncheckall
   for i = 0, #permList:GetChoices() do
      permList:SetChecked(i, false)
   end
   ------------------------------------
   
   for i = 0, #permList:GetChoices() do
      for ii,vv in pairs (App.USERS[sSelText]:GetAccess()) do
         if ii == i then
            permList:SetChecked(ii,vv)
         end
      end
   end
end


--[[

function permSave:OnClick () 
  local DBTable = require "libs.thdben"             --> Facilidades para bases de datos
  local USERS_TABLE = DBTable ( "testing.db", "USERS_TABLE", "user_name text, user_pass varchar (50), user_access text", "user_id")
  local item = USERS_TABLE:search(usersCombo:GetItemText( usersCombo:GetSelection() ), "user_name")
  item.user_access = ''
  for i = 0, #permList:GetChoices() do
    local usr_obj = App.USERS[usersCombo:GetItemText( usersCombo:GetSelection())]
    
    if permList:GetChecked(i) then
      item.user_access = item.user_access .. i .. '|'
      usr_obj:AddAccess(i)
    else
      usr_obj:RemoveAccess(i)
    end 
    
  end
  item.user_access = item.user_access:sub(1, #item.user_access -1) -- Eliminar el ultimo '|'
  print(item.user_access)
  USERS_TABLE:update(item.user_id, {
    user_access = item.user_access
  })
  -- reload users
  tW:Hide()
end

function permCancel:OnClick ()
   tW:Hide()
end

tW.usersCombo = usersCombo
]]

App.AddResource(App.MODULES.M_MANAGE_PERMS, function ( resID )
      tW:show()  
end)

return tW