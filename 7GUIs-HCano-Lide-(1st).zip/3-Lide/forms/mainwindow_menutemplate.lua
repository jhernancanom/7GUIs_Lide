-- Definimos los elementos de la barra de menus:
local Archivos, Movimiento, Procesos, Informes, Utilidades 

Archivos = { Title = "Archivos" }
	
	Archivos[1] = { ID = App.MODULES.MAE_EMPL,
		Text = "Maestro de empleados",
	    -- Dest = "MAE_EMPL"
	}
	
	Archivos[2] = { ID = App.MODULES.TBL_CONCEPTOS,
		Text = "Tabla de conceptos",
	    -- Dest = "TBL_CONCEPTOS"
	}

	Archivos[3] = MENU_SEPARATOR

	Archivos[4] = { ID = App.MODULES.MAE_ADMORAS,
		Text = "Maestro de administradoras",
	    Dest = "TBL_CONCPT"
	}
	
	Archivos[5] = MENU_SEPARATOR
	
	
	Archivos[6] = { ID = App.MODULES.USER_LOGOUT,
		Text = "Cerrar sesion",
	    Dest = "TBL_CONCPT"
	}

Movimiento = { Title = "Movimiento" }
	
	Movimiento[1] = { ID = new 'ID' ,
		Text = "Revisar nomina",
	    Dest = "MAE_EMPL"
	}

	Movimiento[2] = MENU_SEPARATOR

	Movimiento[3] = { ID = MENU_DISABLED ,
		Text = "Prestamos",
	    --Dest = "MAE_EMPL"
	}

	Movimiento[4] = { ID = new 'ID' ,
		Text = "Novedades",
    	-- Dest = "MAE_EMPL"
	}


Procesos = { Title = "Procesos" }
	
	Procesos[1] = { ID = app.MODULES.LIQUIDARFORM,
		Text = "Liquidacion quincenal",
	    Dest = "MAE_EMPL"
	}

	Procesos[2] = { ID = new 'ID' ,
		Text = "Ver archivo XLS",
	    Dest = "MAE_EMPL"
	}

	Procesos[3] = { ID = app.MODULES.PRC_PERIODO_CERRAR,
		Text = "Cerrar quincena",
	    Dest = "MAE_EMPL"
	}

Informes = { Title = "Informes" }
	
	Informes[1] = 'Periodo actual'

	Informes[2] = { ID = new 'ID' ,
		Text = "   Comprobante individual",
	    Dest = "MAE_EMPL"
	}

	Informes[3] = { ID = new 'ID' ,
		Text = "   Contabilizacion",
	    Dest = "MAE_EMPL"
	}

	Informes[4] = MENU_SEPARATOR

	Informes[5] = 'Otros periodos'

	Informes[6] = { ID = app.MODULES.LISTADO_MVNOMINA,
		Text = "   Historico de nomina",
	    Dest = "MAE_EMPL"
	}

	Informes[7] = { ID = new 'ID' ,
		Text = "   Reporte seguridad social",
	    Dest = "MAE_EMPL"
	}

Utilidades = { Title = "Utilidades" }
	
	Utilidades[1] = { ID = new 'ID' ,
		Text = "Fechas del sistema",
	    Dest = "MAE_EMPL"
	}

	Utilidades[2] = { ID = new 'ID' ,
		Text = "Reloj",
	    Dest = "MAE_EMPL"
	}
	
	Utilidades[3] = MENU_SEPARATOR

	Utilidades[4] = { ID = new 'ID' ,
		Text = "Organizacion de archivos",
	    Dest = "MAE_EMPL"
	}

	Utilidades[5] = { ID = new 'ID' ,
		Text = "Copia de seguridad",
	    Dest = "MAE_EMPL"
	}

	Utilidades[6] = { ID = new 'ID' ,
		Text = "Corregir archivos",
	    Dest = "MAE_EMPL"
	}
	
	Utilidades[7] = { ID = App.MODULES.MAE_PERIODOS,
		Text = "Periodos (Datos Vbles)",
	    Dest = "MAE_EMPL"
	}
	
	Utilidades[8] = MENU_SEPARATOR	
	
	Utilidades[9] = { ID = new 'ID' ,
		Text = "Datos empresa",
	    Dest = "MAE_EMPL"
	}
	
	Utilidades[10] = { ID = new 'ID' ,
		Text = "Usuarios",
	    Dest = "MAE_EMPL"
	}
	
	Utilidades[11] = { ID =  App.MODULES.M_MANAGE_PERMS,
		Text = "Permisos",
	}
	

	Utilidades[12] = MENU_SEPARATOR	

	Utilidades[13] = { ID = App.MODULES.REPETIR_NOM,
		Text = "Repetir nomina",
	    ---Dest = "MAE_EMPL"
	}

	Utilidades[14] = { ID = new 'ID' ,
		Text = "Revisar nomina",
	    Dest = "MAE_EMPL"
	}

	Utilidades[15] = MENU_SEPARATOR	
	
	Utilidades[16] = { ID = new 'ID' ,
		Text = "Ayuda",
	    Dest = "MAE_EMPL"
	}

return { Archivos, Movimiento, Procesos, Informes, Utilidades }