require 'extensiones'		-- extensiones al lenguaje lua
require 'modules.classes'  	-- import classes
require 'modules.dbtables' 	-- import database tables

--fork messabox for elementary os visualization:
do
	local msgb = lide.core.base.messagebox
	function lide.core.base.messagebox( str, ... )
		return msgb( '\n' .. str, ...)
	end	
end

App = app

app.modules = { }

app.modules.thdate   = require 'modules.thdate'
app.modules.pprocess = require 'modules.pprocess'

-- Cargamos la lista de usuarios desde el modulo 'users'
App.USERS = require "modules.users"
app.USERS_LIST = App.USERS

-- Cargamos los formularios:
app.windMain        = require 'forms.windmain'
app.formLogin       = require 'forms.loginuser'
app.formMaeAdmoras  = require 'forms.maeadmoras'
app.formMaeEmpl     = require "forms.maempl" 
app.formMaePeriodos = require 'forms.maeperiodos'

app.formCerrarPeriodo   = require 'forms.cerrarperiodo'
app.formRepetirNomina   = require 'forms.repetirnomina'
app.formLiquidarPeriodo = require 'forms.liquidarperiodo'
app.formTablaConceptos  = require 'forms.tablaconceptos'
-- app.formTablaAdmoras    = require 'forms.tablaadmoras'  -- HCM
app.formHistNomina 		= require 'forms.histnomina'

--App.maeadmoras_window   = app.formMaeAdmoras
--App.tblconc_window  	= app.formTablaConceptos
--loginWindow 			= app.formLogin
--App.liquidarform_window = app.formLiquidarPeriodo
--App.mainWindow 			= app.windMain
--maempl_window           = app.formMaeEmpl

app.formLogin:show()