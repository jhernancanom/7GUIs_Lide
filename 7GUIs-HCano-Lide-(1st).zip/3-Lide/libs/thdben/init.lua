--
-- 
-- rev 0001
if  not luasql then
	if lide.platform:getOSName() == 'Unix' then
	   	luasql = require 'luasql.sqlite3'
	else
		local openlib = package.loadlib('./libs/luasql/sqlite3.dll', 'luaopen_luasql_sqlite3')
		luasql = openlib()
	end
end


--

local DBTable
local env = luasql.sqlite3()
local ec, dc
local new = newclass

function ec ( text ) 
	return text 
end 

dc = enc

local function select( dbConnection, tbName, rowNames, sCond )
	local query, con, res = "select %s from %s %s", env:connect(dbConnection), {}
	
	--print(query:format(rowNames, tbName, sCond or ""))

	local cur = assert(
		con:execute(
		query:format(rowNames, tbName, sCond or "")
	))
	
	local row = cur:fetch ({}, "a")
	while row do
		local this = #res+1
		res[this] = {}
		for rowname, rowvalue in pairs(row) do
			res[this][rowname] = rowvalue
		end
		row = cur:fetch ({}, "a")
	end
	cur:close()
	con:close()
	return res
end

local function create_table(dbConnection, tbName, rowNames, recordID)
	local query, con  = "create table %s (%s INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT, %s)", env:connect(dbConnection)

	local cur, errmsg = con:execute("select * from " .. tbName)

	if errmsg and (errmsg:sub(1,22) == "LuaSQL: no such table:") then -- SI LA TABLA NO EXISTE
		local ok_created, error_message = con:execute(query:format(tbName, recordID, rowNames))
		if not ok_created then
			--error(error_message)
			return ok_created, error_message -- false, error_message
		end	
	else
		cur:close()
	end
	
	con:close()
	return true
end
--[[
DBTable = newclass "DBTable"

function DBTable:init( dbname, name, rows, rid )
	rid = rid or DBTable.primarykey
	if not name or not rows then
		error("Needs two arguments DBTable(name, rows).", 3)
	end

	local result, errmsg = create_table(dbname, name, rows, rid )
	if not result then error(errmsg)end
	-- Format rownames : name text, email text, code int, >> name,text,code
	local newrownames = rid
	for i,v in pairs (string.delim(rows, ',')) do
	   if(v:sub(1,1) == ' ')then -- first char is a space
	      v = v:sub(2,#v)
	   end
	   v = v:sub(1, v:find(' '))
       newrownames = newrownames:gsub(' ', '') ..","..v
	end
	-- set values:
	self.database   = dbname
	self.tablename  = name
	self.rownames   = newrownames
	self.primarykey = rid
end

-- return total of rows
function DBTable:getCount( ... )
	return # select(self.database, self.tablename, self.primarykey, 'where '..self.primarykey..' == '.. self.primarykey)
end

-- 1 is RecordID 1
-- db:getRecord(1) 			       --> select all fields of 1
-- db:getRecord(1, '*') 		   --> select all fields of 1
-- db:getRecord(1, 'name, email')  --> select only name and email fields of 1
-- db:getRecord(1, 'name, email')  --> select only name and email fields of 1
-- db:getRecord(1, 'name, email', ' where name == "lol" ')  --> select only name and email fields of 1 where name is the same as "lol"


function DBTable:getRecord( nRecordID, sColumns, sCondition )
	local _arg = nRecordID
	if type(_arg) == 'string' then
		return select( self.database, self.tablename, '*',  str )[1]
	end

	local t = select(self.database, self.tablename, sColumns or '*', 'where '..self.primarykey..' == '.. nRecordID)
	return t[1]
end

function DBTable:insert( item )
	if type(item) ~= "table" then
		error ("argument #1 must be a table.", 3)
	end
	local query, con, rownames, rowvalues = "insert into %s (%s) values (%s)", env:connect(self.database)
	
	for rowname, rowvalue in pairs(item) do
	   if not rownames then
	      rownames = "\""..rowname.."\""
	   else
	      rownames = rownames..", ".."\""..rowname.."\""
	   end

	   if not rowvalues then
	      rowvalues = "\""..ec(rowvalue, PMkey).."\""
	   else
	      rowvalues = rowvalues..", \""..rowvalue.."\""
	   end        
	end
	
	-- formateamos para evitar errores:
	query = query:format(self.tablename, rownames, rowvalues)
	--print(query)
	assert(
		con:execute( query )
	)
	con:close()
end

function DBTable:update( index, item )
	local query, con = "update %s set %s where %s like '%s'", env:connect(self.database)
	local itemf, items = "%s = \"%s\", "

	for rowname, rowvalue in pairs(item) do
		items = (items or '') .. itemf:format(rowname, rowvalue)
	end
	items = items:sub(1, #items-2) -- borro la ultima coma

 	assert(
		con:execute( query:format(self.tablename, items, self.primarykey, index) )
	)
 	
	con:close()
end

function DBTable:list( rows, condition )
	return select(self.database, self.tablename, rows or self.rownames, condition)
end

function DBTable:listi( rows, condition )
	local t, i = self:list( rows, condition ), 0
	return function ()
	    i = i +1;     
	    return t[i] 	
	end
end

function DBTable:search( text, rownames )
	local rownames = rownames or self.rownames
	local text = tostring(text)
	assert(text, "search: argument #1 must be a string")
	for row in self:listi() do
		for rowname in rownames:delimi(',') do
			if row[rowname] then
				if row[rowname]:upper():find(text:upper() or '') then
					return row	
				end
			end
		end
	end
end

function DBTable:delete( condition )
	local query, con = "delete from %s %s", env:connect(self.database)

	-- Si es un numero:
	if tonumber(condition) then
		con:execute ( 
			query:format(self.tablename, 
				string.format("where %s like \"%s\"", self.primarykey, condition) 
			)
		)
	else
		assert(con:execute ( 

			query:format(self.tablename, condition)
		))
	end

	con:close()
end

function DBTable:getcolnames( )
	local query, con, cur, nrow = "select * from %s", env:connect(self.database)
	cur =  assert (
		con:execute (query:format(self.tablename))
	)
	local ret = cur:getcolnames() cur:close()
	return ret
end

function DBTable:getFirstRecord( )
	return select(self.database, self.tablename, '*', 'order by '..self.primarykey..' ASC limit 1')[1]
end

function DBTable:getLastRecord( )
	return select(self.database, self.tablename, '*', 'order by '..self.primarykey..' DESC limit 1')[1]
end

function DBTable:emptyTable( )
	local query, con = 'delete from %s', env:connect(self.database)
	print(self.tablename)
		assert(con:execute ( 
			query:format(self.tablename)
		))
	
	con:close()
end

-- function dbf.getcoltypes( dbf_table_name )
-- 	local query, cur, nrow = "select * from %s"
-- 	cur =  assert (
-- 		dbf.con:execute (query:format(dbf_table_name))
-- 	)
-- 	local ret = cur:getcoltypes() cur:close()
-- 	return ret
-- end

return DBTable
]]

--[[

_DatabaseName = "test.db"
Clientes = DBTable( _DatabaseName, "Clients", "name text, email varchar (50)", "Codigo")

Clientes:insert {
	name = "Dario",
	email = "darioca@gg.com",
}

Clientes:list("email")

for row in Clientes:listi("email") do
	print(row.email)
	break
end

item = Clientes:search("thedary", "name,email")
if item then
	print(item.Codigo, item.name, item.email)
end

item = Clientes:search(3, "Codigo")
if item then
	print(item.Codigo, item.name, item.email)
end

item = Clientes:search "dARio"
if item then
	print(item.Codigo, item.name, item.email)
end

Clientes:update(7, {
		name = "DarioCano",
		email = "el avion se aca"
	})


--Clientes:delete("where name like 'Dario'")
Clientes:delete(1)


]]
return DBTable