require "init" -- require "thdben"

_DatabaseName = "test.db"

Clientes = DBTable ( _DatabaseName, "Clients", "name text, email varchar (50)", "Codigo")



Clientes:insert {
	name = "Dario",
	email = "darioca@gg.com"
}

Clientes:list("email")

for row in Clientes:listi("email") do
	print(row.email)
	break
end

item = Clientes:search("thedary", "name,email")

if item then
	print(item.Codigo, item.name, item.email)
end

item = Clientes:search(3, "Codigo")
if item then
	print(item.Codigo, item.name, item.email)
end

item = Clientes:search "dARio"
if item then
	print(item.Codigo, item.name, item.email)
end

Clientes:update(2, {
		name = "DarioCano",
		email = "dc@gmail.com",
})


--Clientes:delete("where name like 'Dario'")
Clientes:delete(5)