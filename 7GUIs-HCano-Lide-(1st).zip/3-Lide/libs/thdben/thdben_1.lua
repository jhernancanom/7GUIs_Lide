------------------------------------------------------------------------------------------------
-- thdben: thedary's database engine
--
-- Classes: DBTable
--      Methods: reload(string rownames), 
--               list(string rownames), 
--               insert (table rows and values),
--               update(number, table rows and values), 
--               delete(number), 
--               search(string Text to search, string Columns to search)
-- PROBLEMAS CONOCIDOS 
--- errores con multilinea: DBTable:new [[tar text]]
------------------------------------------------------------------------------------------------
require "thoop"
require "luaf"
-- load driver
require "luasql.sqlite3"

-- create environment object
env = assert (luasql.sqlite3())

function dc( ... )
   return arg[1]
end

function ec( ... )
   return arg[1]
end

function sql_select(tbname, rows, cond)
   if not cond then cond = "" end

   local cur, row, t, tdata, nrow

   t, tdata, nrow = {}, {}, 0
   
   cur,a =  con:execute ("SELECT "..rows.." from "..tbname.." "..cond)
   --print(cur, a)
   if type(cur) == "userdata" then
      row = cur:fetch ({}, "a")
      while row do
            nrow = nrow + 1
            tdata = {}
            for rowname, value in pairs(row) do
               if rowname ~= "recordid" then
                  value = dc(value, PMkey)
               end

               tdata[rowname] = value
               t[nrow] = tdata
               --print(rowname, value)
            end
         row = cur:fetch (row, "a")
      end
      cur:close()
      return t
   end
--   con:close()
end

DBTable = new "class"

DBTable {
   dbName = "new-dben-test.db",

   function ( self, ... )
      local query  = "create table %s (recordid INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT, %s)"
      
      if not self.name then
         self.name = getvname(self)
      end
      
      local tbName = self.name

      if not self.columns then
         self.columns = arg[1]--- self.name -- En este caso al llamar self:new "aaa" no es 'Name' si no 'columns'
      end
           
      con = env:connect(self.dbName)     
      con:execute(query:format(tbName, self.columns))
      con:close()
      -- Limpiamos los rownames para que en vez de ser asi: name text, email, text, code integer... sean asi: name,emial,code
      newrownames = ""
      for i,v in pairs (delim(self.columns, ',')) do
         if(v:sub(1,1) == ' ')then -- Si el primer caracter es un espacio
            v = v:sub(2,#v)
         end
         v = v:sub(1, v:find(' '))
         if newrownames == '' then
            newrownames = v
         else
            newrownames = newrownames..","..v
         end
      end
      self.columns = newrownames:gsub(' ', '')
      return table.copy(self)
   end,

   insert = function ( self, tValues)
      local rownames, rowvalues, query
      query  = "insert into %s (%s) values (%s)"
      
      for rowname, rowvalue in pairs(tValues) do
         if not rownames then
            rownames = "'"..rowname.."'"
         else
            rownames = rownames..", ".."'"..rowname.."'"
         end

         if not rowvalues then
            rowvalues = "'"..ec(rowvalue, PMkey).."'"
         else
            rowvalues = rowvalues..", '"..rowvalue.."'"
         end        
      end
      con = env:connect(self.dbName)
      con:execute(query:format(self.name, rownames, rowvalues))
      self:reload(self.columns)
      con:close()
   end,

   list = function (self, rownames, cond)
      if not rownames then
         rownames = ""
      end
      self:reload(self.columns)
      con = env:connect(self.dbName)
      local sql_result = sql_select(self.name, "recordid, "..rownames, cond)
      con:close()
      return sql_result
   end,

   reload = function (self, rownames)
      con = env:connect(self.dbName)
      local newtb = sql_select(self.name, "recordid, "..rownames)

      con:close()
      for pos, tdata in pairs(newtb) do
         self[pos] = tdata
      end
   end,

   update = function (self, index, values)
      local query, coma
      if  assert (tonumber(index), "update() arg2 > El indice debe ser un numero") 
      and assert (tostring(value), "update() arg 3 > Debe ingresar una tabla") then
         
         query, coma = "update "..self.name.." set ", ", "

         for rowname, rowval in pairs(values) do
            if rowname ~= "recordid" then
               rowval = ec(rowval, PMkey)
            end

            query = query..rowname.." = \""..rowval.."\" "..coma
         end
         
         query = query:sub(1, #query-2).. "where recordid like \""..index.."\""
         print(query)
         con = env:connect(self.dbName)
         assert(con:execute(query))

         self:reload(self.columns)
         con:close()
      end
   end,
   
   delete = function (self, recordid)
      local query = "delete from " ..self.name.." where recordid like \""..recordid.."\""
      con = env:connect(self.dbName)
      assert(con:execute(query))
      table.remove(self,  recordid)
      self:reload(self.columns)
      con:close()
   end,

   search = function (self, ...)
      local tresult, tosearch, tos, n = {}
      --Limpiamos los espacios:
      if not arg[2] then
         arg[2] = self.columns
      end
      arg[2] = arg[2]:gsub(' ', '')

      if not arg[1] then
         assert (false, "Ingrese un texto para buscar")     
      end
     
      for i = 1, #self do
         if arg[2] then
            tos = delim(arg[2], ",")
         else
            tos = delim(self._tbcols, ",")
         end
         
         n = 0

         repeat
            n = n +1
            tosearch = tos[n]
            --print(tosearch)
            if self[i] then
               if string.find(self[i][tosearch]:upper(), arg[1]:upper()) then
                  --print(self[i][tosearch])
                  tresult[#tresult + 1] = i -- Devolvemos el indice
               end
            end
         until n == #tos
      end
      
      return tresult
      -- People:search("textToSearch", "colsT,oSearch")
   end
}