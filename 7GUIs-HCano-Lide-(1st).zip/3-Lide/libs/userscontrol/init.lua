-- USERS MODULE:

local appUser = class "appUser" : global(false)

function appUser:appUser ( sUserName, sPassword )

	self.HasAccess = { }
	self.Password  = sPassword
    self.UserName  = sUserName
end

function appUser:AddAccess( mod_string )
	rawset(self.HasAccess, mod_string, true)
end

function appUser:RemoveAccess( mod_string )
    rawset(self.HasAccess, mod_string, false)
end

function appUser:HasAccessTo( mod_string )
	local perm = rawget(self.HasAccess, mod_string)
	if perm == nil then perm = false end
	return perm
end

function appUser:GetUserName ()
    return tostring(self.UserName)
end

function appUser:GetPassword()
    return tostring(self.Password)
end

function appUser:GetAccess()
    return self.HasAccess
end

return appUser

--[[ /////////////////////////////////////////
enum {
	M_SETTINGS = "SettingsWindow",
	M_CLIENTES = "ClientsWindow" ,
}

thisWindow = M_SETTINGS

usr = appUser:new {
	Password = "defalutpassword"
}

if not usr:HasAccesTo(M_SETTINGS) then
	print "Does NOT have acces to Settings"
end
]]