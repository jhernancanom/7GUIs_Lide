local DBTable = require 'libs.thdben.dbtable'             --> Facilidades para bases de datos

SQLT = {}

SQLT.NOMMAE = DBTable ( 
	'testing.db'  , 'TABLA_NOMMAE', 
	--'Codigo text, Activo text, Documento text, Nombre text, Apellidos text, Telefono text, AFP text, EPS text, CCF text, CES text, Salario text, Email text, Cargo text, FechaING text, FechaREI text, FechaRET text',
	'CODIGO text, ACTIVO string, DOCUMENTO string, NOMBRE string, APELLIDOS string, AFP string, EPS string, CCF string, CES string, SALARIO string, EMAIL string, CARGO string, FECHA_ING string, FECHA_REI string, FECHA_RET string, CUENTA string, TELEFONO string, TIEMPO string, CCOSTOS string',
	'recordid'
)

SQLT.CONCEPTOS = DBTable ( 
	'testing.db'  , 'TABLA_CONCEPTOS', 
	'CODIGO text, NUMERO string, CEDULA number, QUINCENA string, DESCRIPCIO string, OBSERVACIO string, DEV_DED string, ADMORA string, PORCENTAJE string, VARIABLE string, FORMULA string, VALOR number, DIAS number',
	'recordid'
)


SQLT.ADMORAS = DBTable ( 
	'testing.db'  , 'TABLA_ADMORAS', 
	'CODIGO string, ACTIVA string, NIT string, DESCRIPCIO string, TIPO string, CODIGOMPS string, NOMBRE string, EMAIL string',
	'recordid'
)

SQLT.NOMMOV = DBTable ( 
	'testing.db'  , 'TABLA_NOMMOV', 
	'CODIGO text, NUMERO string, CEDULA number, QUINCENA string, DESCRIPCIO string, OBSERVACIO string, DEV_DED string, ADMORA string, PORCENTAJE string, VARIABLE string, FORMULA string, VALOR number, DIAS number',
	'recordid'
)

SQLT.PERIODOS = DBTable ( 
	'testing.db'  , 'TABLA_PERIODOS', 
	'PERIODO text, DESCRIPCIO text, FEC_INICIA text, FEC_TERMIN text, ABIERTO text, VR_TRASPOR text, S_MINIMO text',
	'recordid'
)

SQLT.SYSTBL = DBTable ( 
	'testing.db'  , 'SYSTBL', 
	'NIT string, EMPRESA string, TEL string, FAX string, EMAIL string, FEC_I string, SUC string, ARL string, CES string, RIE string, C_PRE string, ORDEN string',
	'recordid'
)

SQLT.USERS = DBTable ( 
	'testing.db', 'USERS_TABLE',
	'user_name text, user_pass varchar (50), user_access text',
	'user_id'
)

SQLT.NOMHIST = DBTable:new ( 
	'testing.db'  , 'TABLA_NOMHIST', 
	'CODIGO text, NUMERO string, CEDULA number, QUINCENA string, DESCRIPCIO string, OBSERVACIO string, DEV_DED string, ADMORA string, PORCENTAJE string, VARIABLE string, FORMULA string, VALOR number, DIAS number',
	'recordid'
)

return SQLT