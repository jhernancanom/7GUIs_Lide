-- Define class constants:
enum { 
	HTML_TEMPLATE = [[
   		CERRAR PERIODO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[ %s ]
			<p>
				%s
			</p>
	]]
}

-- Define a global class:
local HTMLView = lide.classes.controls.htmlview

class 'HTMLReport' : subclassof 'HTMLView'

function HTMLReport:HTMLReport( fields )
	self.super : init ( fields )

	private {
		Text = fields.Text or HTML_TEMPLATE
	}
end

function HTMLReport:printLn ( sLine )
	self.Text = self.Text:gsub('__linecontent__', tostring(sLine)) .. '<br>__linecontent__'

	self:loadCode( 
		self.Text:gsub('__linecontent__', '')
	)
end

function HTMLReport:setText ( sLine )
	self.Text = sLine

	self:loadCode ( 
		self.Text
	)
end
