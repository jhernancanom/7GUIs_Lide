-- ///////////////////////////////////////////////////////
-- Create users:

-- Funciones que exporta;:
--- bool App.RequestAccess( numnber itemID ) -- intentar acceder al recurso con el usuario logeado actualmente (App.loggedUser)
--- object[appUser] App.loggedUser -- usuario logeado
--- enum App.MODULES -- Lista de modulos de la aplicacion


local DBTable = require "libs.thdben.dbtable"             --> Facilidades para bases de datos
local appUser = require "libs.userscontrol.init"  --> Control de usuarios

App.loggedUser = appUser:new("nadie", "nadie")

-- Definimos los posibles permisos para los usuarios:
App.MODULES = {
    M_VIEW_CLIENTS     = 0,
    M_ADD_CLIENTS      = 1,
    M_EDIT_CLIENTS     = 2,
    M_MANAGE_PERMS     = 3,
    MAE_EMPL           = 4,
    TBL_CONCEPTOS      = 5,
    MAE_ADMORAS        = 6,
    PROC_LIQUIDAC      = 7,
    LIQUIDARFORM       = 8,
    USER_LOGOUT        = 9,
    MAE_PERIODOS       = 10,
    PRC_PERIODO_CERRAR = 11,
    REPETIR_NOM        = 12,
    LISTADO_MVNOMINA   = 13,
}

-- Definimos los recursos asociados a esos permisos
App.RESOURCES = {} -- Una tabla vacia que iremos llenando mediante App.AddResource

function App.RequestAccess( itemID )
  if App.loggedUser:HasAccessTo(itemID) then
      return true
  else
      MessageBox ("No tienes acceso al recurso ".. itemID, "Titulo", ICON_WARNING)
      return false
  end
end

function App.AddResource ( resID, resFunc )
    if not resID then
       lide.print_error  'arg #1 not must be nil.'
       return
    end

    App.RESOURCES[resID] =  function ( resID) 
        if App.RequestAccess( resID ) then 
            resFunc( resID )
        end
    end
end

App.addResource = App.AddResource
  
-- Creamos/Cargamos la tabla SQL:
local USERS_TABLE = DBTable ( "testing.db", "USERS_TABLE", "user_name text, user_pass varchar (50), user_access text", "user_id")

users_list = {} -- array donde se guardan los usuarios

-- Recorrer la tabla de usuarios
for row in USERS_TABLE:listi("user_name, user_pass, user_access")do
  local usr_name   = row.user_name
  local usr_pass   = row.user_pass
  local usr_access = row.user_access 
  usr_object = appUser:new (usr_name, usr_pass) --> Creamos un objeto de la clase appUser para interactuar con el
  
  -- Agregar los permisos que tiene en la base de datos:
  for value in usr_access:delimi() do
     if tonumber(value) then
      usr_object:AddAccess( tonumber(value) ) 
     end
  end
  users_list[usr_name] = usr_object 
end

return users_list