-- liquidar_nomina.lua
-- 	'PERIODO string, DESCRIPCIO string, FEC_INICIA string, FEC_TERMIN string, ABIERTO string, CERRADO string, TIT_NOMINA string, TIT_PREST string, VR_TRASPOR string, S_MINIMO string, PORC_PENSI string, PORC_SALUD string, ORDENAR string, UBIXLS string, CP_CUENTA string, CP_NIT string, CP_DETALLE string',

--local MessageBox = lide.core.base.messagebox


--local Sleep = wx.wxSleep

function fexeh ( EmpleadoActual, PeriodoActual, formula, variables )
	local env = {
		BASICO   = tonumber(EmpleadoActual.SALARIO) ,
		SMLMV    = tonumber(PeriodoActual.S_MINIMO) ,
		DIAS     = tonumber(_DIAS)  			    ,
		AFP      = tonumber(EmpleadoActual.AFP)     ,
		TIBC     = tonumber(_TIBC)				    ,
		TDEV     = tonumber(EmpleadoActual.TDEV)    ,
		TDED     = tonumber(EmpleadoActual.TDED)    ,
		T001     = tonumber(EmpleadoActual.T001)    ,
		BASTRANS = tonumber(PeriodoActual.VR_TRASPOR)
	}
	
	local formula = formula or '0' --> Si el concepto no tiene formula entonces devuelve cero.
	
	if formula:sub(1,3) ~= 'if ' then
		formula = 'return ' .. formula
	end
	
	local ejecucion = loadstring( formula )
	setfenv(ejecucion, env)
	
	local nResult
	local x,e = pcall(ejecucion)
	
	if not x then
		pperror(e)
	else
		nResult = e
	end

	-- Sumamos las variables:				
	for word in variables:delimi ';' do
		if not rawget(EmpleadoActual, word) then
			rawset(EmpleadoActual, word, 0)
		end
		EmpleadoActual[word] = EmpleadoActual[word] + nResult
	end
	
	return math.round(nResult, 2) -- Redondeamos el resultado de la funcion a dos decimales
end

--require "dbs"

function LIQUIDAR ( ... )
	-- Si la tabla Movimiento de Nomina tiene registros, se le informa al usuario que no se ha 
	-- cerrado la quincena anterior:
	--
	
	if SQLT.NOMMOV:getCount() > 0 then
		 
		 pperror'No se ha cerrado la quincena anterior'
		 return false
	else
		local T = {}
		-- Abre la tabla 'PERIODOS' y obtiene las variables que se necesitan del periodo que esté
		-- abierto 
		--
		local PeriodoActual = rawget( SQLT.PERIODOS:list('*', 'where ABIERTO == "S"'), 1) -- Abrimos el primer registro
		
		if not PeriodoActual then
			pperror "Por alguna extraña razon no hay ningun periodo abierto."
		else 
			local EmpleadosActivos = SQLT.NOMMAE:list('*', 'where ACTIVO == "S"')
		
			for iEmpleado, EmpleadoActual in pairs(EmpleadosActivos) do
				local EstosConceptos = SQLT.CONCEPTOS:list '*'
				_DIAS          = 15 --inicio del periodo al fin del periodo aveces no hayquince
				_TIBC          = 0
				
				_QUINCENA	   = PeriodoActual.PERIODO 
				
				-----------------------------------------------
				--- DIAS A PAGAR

				--print (  )

				-->>>>>>

				-- Generar un cursor temporal con la misma estructura e informacion de la tabla CONCEPTOS
				--
				 for i, concepto in pairs (EstosConceptos) do
					-- Ejecutamos la funcion del concepto:
					concepto.VALOR      = fexeh( EmpleadoActual, PeriodoActual, concepto.FORMULA, concepto.VARIABLE or '')
					concepto.CEDULA     = EmpleadoActual.DOCUMENTO
					concepto.QUINCENA   = _QUINCENA
					concepto.ADMORA     = EmpleadoActual[concepto.ADMORA] or ''
					concepto.NUMERO     = iEmpleado
					concepto.DIAS       = _DIAS				
					--concepto.DESCRIPCIO = concepto.DESCRIPCIO

					concepto.recordid = nil
					--Sleep(0.000001)
				end
				EmpleadoActual.CONCEPTOS = EstosConceptos
				T[#T +1] = EmpleadoActual
			end
		end
		return T
	end
end
return LIQUIDAR

--[[
te = LIQUIDAR()

for i, empleado in pairs(te) do
	-- Buscamos los conceptos dentro de la tabla de 'empleado'
	--
	print('\n-' .. empleado.NOMBRE .. ':\n')
	for _, Concepto in pairs(empleado.CONCEPTOS) do
		print('\t'.. Concepto.DESCRIPCIO)
		SQLT.NOMMOV:insert(Concepto)
	end	
end
]]