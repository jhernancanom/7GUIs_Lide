-- la quincena ya esta cerrada, debe liquidar la nomina actal
-- este es el periodo que voy a cerrar
-- esta seguro
-- get todo nomov
-- pasa get nommov a historico
-- borra todo de nommov
-- tabla periodos lo marca como cerrado

local infoStatus, lblCodigo, lblPeriodo, gauProgress, btnSearch

local Sleep = wx.wxSleep

-- Creamos una funcion especial que nos permita imprimir lineas en el textbox 'infoStatus'
-- 
local function println( text )
	infoStatus:SetInsertionPoint(  infoStatus:GetLastPosition() )
	infoStatus:WriteText(text)
	infoStatus:WriteText('\n')
end

local function CerrarPerido ( Periodo )
	local PrimaryKey = SQLT.PERIODOS.primarykey
	local RecordID   = Periodo[PrimaryKey]	
	
	-- Movemos los registros desde NOMMOV hasta NOMHIST
	--
	local nom_mov = SQLT.NOMMOV:list 'CODIGO, NUMERO, CEDULA, QUINCENA, DESCRIPCIO, OBSERVACIO, DEV_DED, ADMORA, PORCENTAJE, VARIABLE, FORMULA, VALOR, DIAS'	
	
	local str = '[%s ] %s'

	for iConcepto, Concepto in pairs (nom_mov) do
		local str = '[%s...] %s'
		println( str:format(Concepto.CEDULA:sub(1,7), Concepto.DESCRIPCIO) )
		SQLT.NOMHIST:insert(Concepto)
		gauProgress:SetCurrentPos(iConcepto / # nom_mov * 100, true)
	end

	-- Eliminamos todo de la tabla NOMMOV y marcamos el periodo como cerrado.
	--
	SQLT.NOMMOV:emptyTable()
	SQLT.PERIODOS:update(RecordID, { ABIERTO = 'N' })

	println '\n'
	println( str:format(Periodo.PERIODO:sub(1,10), 'Periodo archivado exitosamente en el historico de nomina.' ) )
	
	--local str = 'El periodo %s se cerro exitosamente.'
	--MessageBox (str:format(Periodo.PERIODO), 'Nomina')
end

local tW = Window:new { Name = 'liquidForm',
	Title = 'Cerrar periodo',
	Width = 550, Height = 250
} --> this Window

tW.onShow:setHandler(function (  )
	infoStatus:SetText ''
end, tW)

-- Interceptamos OnClose para que la ventana no se destruyan por defecto cuando la cerramos.
--
tW.OnClose:setHandler(function (  )
 	this:getSender():Hide()
end)

infoStatus = Textbox:new { Name =  ( tW.Name .. '.infoStatus' ),
	Parent = tW,
	Flags  = TB_READONLY + TB_MULTILINE,
	Text   = '', Font   = 'Courier New'
}

lblCodigo = Label { Name =  ( tW.Name .. '.lblCodigo' ),
  Parent = tW,
  Text = "Se va a cerrar el periodo:",
}

lblPeriodo = Label { Name =  ( tW.Name .. '.lblPeriodo' ),
  Parent = tW,
  Text = "01/12/2015-2",
}

lblPeriodo:SetFont( lblPeriodo:GetFont():GetDescString() .. ', Bold' )

btnSearch = Button:new { Name =  ( tW.Name .. '.btnSearch' ),
  Parent = tW, 
  PosX   = 700, PosY = 5,

  Text = "Cerrar periodo",
}

gauProgress = Progress:new { Name =  ( tW.Name .. '.gauProgress' ),
	Parent = tW, 
	Height = 23, Width = -1,
	Style = PROGRESS_SMOOTH,
	MaxValue = 99
}

btnSearch.OnClick:setHandler( function ( void )
	local PeriodoAbierto for row in SQLT.PERIODOS:listi ('*', 'where ABIERTO LIKE "S"') do
	    	PeriodoAbierto = row
	    	break
    end
    if PeriodoAbierto then	
		CerrarPerido( PeriodoAbierto )
	else
		 MessageBox("No hay un periodo abierto", "lide-framework")
	end

	--[[	
	infoStatus:SetText('') --> -- Limpiamos el Textbox de Status

	local steps = {} for iEmpleado, empleado in pairs(Liquidados or {}) do
		-- Buscamos los conceptos dentro de la tabla de 'empleado'
		--
		steps[iEmpleado] = iEmpleado / #Liquidados * 100
		println(('CC: %d, NOMBRE: %s \n'):format(empleado.DOCUMENTO, empleado.NOMBRE))
    for iConcepto, Concepto in pairs(empleado.CONCEPTOS) do		
			gauProgress:SetCurrentPos(iConcepto / # empleado.CONCEPTOS * steps[iEmpleado], true)
			println('\t'.. Concepto.DESCRIPCIO)

			SQLT.NOMMOV:insert( Concepto )
			Sleep(0.000001)
		end
		println '\n'
	end
	gauProgress:SetCurrentPos(100)
	]]
end)

 
tW.Sizer = BoxSizer ( VERTICAL )  
tW.Panel:SetSizer( tW.Sizer )

tW.Panel.SizerUno = BoxSizer ( HORIZONTAL )  
tW.Panel.SizerDos = BoxSizer ( VERTICAL )

tW.Sizer:Add(tW.Panel.SizerUno, 0, EXPAND + ALIGN_CENTER_HORIZONTAL + BOTTOM, 10 )
tW.Sizer:Add(tW.Panel.SizerDos, 1, EXPAND + ALIGN_CENTER + ALL              , 10 )
  
tW.Panel.SizerUno:Add( lblCodigo , 0, TOP + LEFT + RIGHT, 10)
tW.Panel.SizerUno:Add( lblPeriodo, 1, TOP + EXPAND      , 10)
tW.Panel.SizerUno:Add( btnSearch , 0, TOP + LEFT + RIGHT, 5 )

tW.Panel.SizerDos:Add( infoStatus , 1, EXPAND           , 0 )
tW.Panel.SizerDos:Add( gauProgress, 0, EXPAND + TOP     , 5 )

tW.infoStatus  = infoStatus
tW.lblCodigo   = lblCodigo
tW.lblPeriodo  = lblPeriodo
tW.gauProgress = gauProgress

App.AddResource(App.MODULES.PRC_PERIODO_CERRAR, function ( resID )
    local PeriodoAbierto for row in SQLT.PERIODOS:listi ('*', 'where ABIERTO LIKE "S"') do
    	PeriodoAbierto = row
    	break
    end

    if PeriodoAbierto then
--[[    	local msg = 'Vamos a cerrar el periodo %s\n\nFecha inicio: %s\t\tFecha fin: %s\n\nContinuar?'
    		
		local PeriodoAbierto for row in SQLT.PERIODOS:listi ('*', 'where ABIERTO LIKE "S"') do
	    	PeriodoAbierto = row
	    	break
	    end

	    if PeriodoAbierto then
	    	msg = MessageBox(
	    		msg:format( PeriodoAbierto.PERIODO, PeriodoAbierto.FEC_INICIA, PeriodoAbierto.FEC_TERMIN  ),
	    		'Cerrar periodo', NO_DEFAULT + YES_NO
	    	)
	    	if (msg == YES) then
	    		CerrarPerido( PeriodoAbierto )
	    	end
	    end]]
	    tW	:show()
    else
	    MessageBox 'No hay ningun periodo abierto.\n\nLa quincena ya esta cerrada, debe liquidar la nomina actual.'
    	App.maeperiodos_window:show()
    end
end)

return tW

------------------------------------------------------------------
--   
--   Vamos a cerrar el periodo 2012-10-1
--
--	 �Esta seguro?
--   
--   Fecha de inicio: 2012-10-1			Fecha Termino: 2012-10-15
--   
--   
--   	CANCELAR								CONTINUAR
--   
------------------------------------------------------------------