--.. based on xlsxwriter 0.0.6

-- load required libraries:
local check = lide.core.base.check

-- load required funcitons:
local isString = lide.core.base.isstring
local isNumber = lide.core.base.isnumber
local isObject = lide.core.base.isobject
local isTable  = lide.core.base.istable

-- load required classes:
local Object       = lide.classes.object
local NumberSheet  = require 'XLSX.numbersheet'

---
--- class definition:
---
local NumberBook = class 'NumberBook' : subclassof 'Object'
	: global(false)

function NumberBook:NumberBook ( fields )

	check.fields {
		'string Name', 'string Filename'
	}

	private {
		Filename = fields.Filename,
		Cobj     = {}
	}

	-- object Object:new ( string sObjectName, number nObjectID )
	self.super:init ( fields.Name, fields.ID  or lide.core.base.newid() )
	
	-- load required libraries locally 	
	local Workbook = require 'xlsxwriter.workbook'	

	--- create the current object:
	--table Workbook:new( filename[,options] )
	self.Cobj = Workbook:new ( self.Filename, nil )
end

--[table *format] workbook:add_format(table [properties])
function NumberBook:newFormat ( fields )
	
	local format = self.Cobj:add_format {
		bold = fields.Bold or nil,
		font_size = fields.FontSize or nil,
		font_name = fields.FontName or nil,
	}

	format:set_font_name ( fields.FontName or nil )
	
	return format
end

-- worksheet workbook:add_worksheet([sheetname])
function NumberBook:addSheet( strName )
	isString(strName)

	return NumberSheet:new ( self.Cobj, strName )
end

function NumberBook:close( )
	self.Cobj:close()
end

function NumberBook:getCobj ( ... )
	return self.Cobj
end

return NumberBook